import { useParams, Link } from 'react-router-dom'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Grid3X3,
  List,
  Search,
  Eye,
  Clock,
  Pin,
  Filter,
  ChevronRight,
  ArrowLeft,
} from 'lucide-react'
import { mockLinks, mockCategories } from '@/data/mock'
import { formatNumber, getDaysRemaining } from '@/lib/utils'

export default function CategoryPage() {
  const { id } = useParams<{ id: string }>()
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sortBy, setSortBy] = useState<'recent' | 'popular'>('recent')
  const [searchQuery, setSearchQuery] = useState('')

  // 找到当前分类
  const category = mockCategories.find((c) => c.id === id) || mockCategories[0]
  
  // 筛选该分类的链接
  let filteredLinks = mockLinks.filter((l) => l.category_id === id)
  
  // 搜索过滤
  if (searchQuery) {
    filteredLinks = filteredLinks.filter((l) =>
      l.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
  }
  
  // 排序
  if (sortBy === 'popular') {
    filteredLinks = [...filteredLinks].sort((a, b) => b.click_count - a.click_count)
  } else {
    filteredLinks = [...filteredLinks].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    )
  }

  // 置顶链接放在最前面
  const pinnedLinks = filteredLinks.filter((l) => l.is_pinned)
  const regularLinks = filteredLinks.filter((l) => !l.is_pinned)
  const sortedLinks = [...pinnedLinks, ...regularLinks]

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 面包屑 */}
      <motion.nav
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-2 text-sm text-gray-500 mb-6"
      >
        <Link to="/" className="hover:text-blue-600">首页</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-gray-800 font-medium">{category.name}</span>
      </motion.nav>

      {/* 分类头部 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl p-8 shadow-sm border mb-8"
      >
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center shadow-md">
            <img
              src={category.logo_url || ''}
              alt={category.name}
              className="w-14 h-14 object-contain"
              onError={(e) => {
                e.currentTarget.src = 'https://img.icons8.com/color/144/cloud.png'
              }}
            />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">{category.name}</h1>
            <p className="text-gray-500">
              共 {filteredLinks.length} 个资源
            </p>
          </div>
        </div>
      </motion.div>

      {/* 工具栏 */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6"
      >
        {/* 搜索框 */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="搜索该分类下的资源..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="flex items-center gap-3">
          {/* 排序 */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'recent' | 'popular')}
            className="px-4 py-2 bg-white border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="recent">最新优先</option>
            <option value="popular">热门优先</option>
          </select>

          {/* 视图切换 */}
          <div className="flex items-center bg-white border rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'grid'
                  ? 'bg-blue-100 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Grid3X3 className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'list'
                  ? 'bg-blue-100 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* 结果列表 */}
      <AnimatePresence mode="wait">
        {sortedLinks.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <Filter className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">没有找到相关资源</p>
            <p className="text-gray-400 text-sm mt-2">
              尝试其他关键词或浏览其他分类
            </p>
          </motion.div>
        ) : viewMode === 'grid' ? (
          <motion.div
            key="grid"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid md:grid-cols-3 lg:grid-cols-4 gap-4"
          >
            {sortedLinks.map((link, index) => (
              <motion.div
                key={link.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Link
                  to={`/s/${link.slug}`}
                  className="block bg-white rounded-xl border hover:border-blue-200 hover:shadow-lg transition-all overflow-hidden group"
                >
                  {/* 置顶标记 */}
                  {link.is_pinned && (
                    <div className="absolute top-2 left-2 z-10">
                      <span className="px-2 py-1 bg-amber-500 text-white text-xs rounded-full flex items-center gap-1">
                        <Pin className="w-3 h-3" />
                        置顶
                      </span>
                    </div>
                  )}
                  
                  <div className="aspect-video bg-gradient-to-br from-gray-50 to-gray-100 relative">
                    <img
                      src={link.category_logo || ''}
                      alt=""
                      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 object-contain opacity-30"
                    />
                    <div className="absolute bottom-2 right-2 bg-white/90 rounded-full p-2 shadow-sm">
                      <img
                        src={link.category_logo || ''}
                        alt=""
                        className="w-6 h-6 object-contain"
                      />
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium text-gray-800 group-hover:text-blue-600 transition-colors line-clamp-2 mb-2">
                      {link.name}
                    </h3>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {formatNumber(link.click_count)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {getDaysRemaining(link.expires_at) === null
                          ? '永久'
                          : `${getDaysRemaining(link.expires_at)}天`}
                      </span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-3"
          >
            {sortedLinks.map((link, index) => (
              <motion.div
                key={link.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Link
                  to={`/s/${link.slug}`}
                  className="flex items-center gap-4 p-4 bg-white rounded-xl border hover:border-blue-200 hover:shadow-md transition-all group"
                >
                  {/* 置顶标记 */}
                  {link.is_pinned && (
                    <span className="px-2 py-1 bg-amber-500 text-white text-xs rounded-full flex items-center gap-1">
                      <Pin className="w-3 h-3" />
                      置顶
                    </span>
                  )}
                  
                  {/* 图标 */}
                  <div className="w-12 h-12 rounded-xl bg-gray-50 flex items-center justify-center flex-shrink-0">
                    <img
                      src={link.category_logo || ''}
                      alt=""
                      className="w-8 h-8 object-contain rounded-xl"
                    />
                  </div>
                  
                  {/* 内容 */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-gray-800 group-hover:text-blue-600 transition-colors truncate">
                      {link.name}
                    </h3>
                    <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {formatNumber(link.click_count)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {getDaysRemaining(link.expires_at) === null
                          ? '永久有效'
                          : `${getDaysRemaining(link.expires_at)}天后过期`}
                      </span>
                    </div>
                  </div>
                  
                  {/* 箭头 */}
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-blue-600 transition-colors" />
                </Link>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* 返回按钮 */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mt-12 text-center"
      >
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-blue-600 hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          返回首页
        </Link>
      </motion.div>
    </div>
  )
}
