import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  Search,
  Star,
  ExternalLink,
  Eye,
  Copy,
  Check,
  FolderOpen,
  Sparkles,
  ChevronDown,
  ChevronRight,
  Menu,
  X,
  List,
  Grid,
} from 'lucide-react'
import { mockCategories, mockLinks, mockSubCategories } from '@/data/mock'

export default function HomePage() {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(mockCategories[0]?.id || null)
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>(null)
  const [expandedCategory, setExpandedCategory] = useState<string | null>(mockCategories[0]?.id || null)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [showMobileSidebar, setShowMobileSidebar] = useState(false)
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list')
  const [selectedLink, setSelectedLink] = useState<typeof mockLinks[0] | null>(null)
  const itemsPerPage = 10

  const featuredLinks = mockLinks.filter(link => link.is_featured)
  
  const filteredLinks = mockLinks.filter(link => {
    const matchesCategory = selectedCategory ? link.category_id === selectedCategory : true
    const matchesSubCategory = selectedSubCategory ? link.subcategory_id === selectedSubCategory : true
    return matchesCategory && matchesSubCategory
  })

  const totalPages = Math.ceil(filteredLinks.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedLinks = filteredLinks.slice(startIndex, startIndex + itemsPerPage)

  const getSubCategories = (categoryId: string) => {
    return mockSubCategories.filter(sc => sc.category_id === categoryId)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`)
    }
  }

  const copyToClipboard = async (url: string, id: string) => {
    try {
      await navigator.clipboard.writeText(url)
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const getLinkIcon = (link: typeof mockLinks[0]) => {
    // 如果有自定义图标，显示自定义图标
    if (link.icon) {
      return (
        <img 
          src={link.icon} 
          alt={link.title}
          className="w-10 h-10 rounded-xl object-cover flex-shrink-0 shadow-lg"
        />
      )
    }
    
    // 否则显示网盘类型图标
    const colors: Record<string, string> = {
      baidu: 'bg-gradient-to-br from-blue-500 to-blue-600',
      quark: 'bg-gradient-to-br from-purple-500 to-purple-600',
      aliyun: 'bg-gradient-to-br from-red-500 to-orange-500',
      lanzou: 'bg-gradient-to-br from-orange-500 to-amber-500',
      xunlei: 'bg-gradient-to-br from-cyan-500 to-blue-500',
    }
    const names: Record<string, string> = {
      baidu: '百度',
      quark: '夸克',
      aliyun: '阿里',
      lanzou: '蓝奏',
      xunlei: '迅雷',
    }
    return (
      <div className={`w-10 h-10 rounded-lg ${colors[link.drive_type] || 'bg-gray-500'} flex items-center justify-center text-white font-bold text-xs flex-shrink-0 shadow-lg`}>
        {names[link.drive_type] || '网盘'}
      </div>
    )
  }

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId)
    setSelectedSubCategory(null)
    setCurrentPage(1)
    if (expandedCategory === categoryId) {
      setExpandedCategory(null)
    } else {
      setExpandedCategory(categoryId)
    }
  }

  return (
    <div className="min-h-screen bg-white text-gray-900 flex flex-col">
      {/* Centered Logo + Search (百度风格) */}
      <div className="flex flex-col items-center pt-20 px-4 pb-10">
        {/* Logo - 左右排列 */}
        <Link to="/" className="flex items-center gap-4 mb-8 group">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-xl shadow-indigo-200/50 group-hover:shadow-2xl group-hover:shadow-indigo-300/50 transition-all duration-300">
            <svg viewBox="0 0 24 24" className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className="text-4xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            资源云
          </span>
        </Link>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="w-full max-w-2xl">
          <div className="relative group">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索您需要的资源..."
              className="w-full px-5 py-3.5 sm:px-6 sm:py-4 pl-12 sm:pl-14 pr-24 sm:pr-28 rounded-full bg-white text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:border-indigo-300 transition-all duration-300 text-sm sm:text-base border border-gray-300 hover:border-gray-400 hover:shadow-md focus:shadow-lg"
            />
            <Search className="absolute left-4 sm:left-5 top-1/2 -translate-y-1/2 w-5 h-5 sm:w-6 sm:h-6 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 px-5 sm:px-8 py-2 sm:py-2.5 bg-indigo-600 text-white text-sm rounded-full hover:bg-indigo-700 transition-all duration-300 font-medium"
            >
              搜索
            </button>
          </div>
        </form>

        {/* Quick Category Buttons */}
        <div className="flex items-center gap-2.5 sm:gap-3 mt-6 sm:mt-8 flex-wrap justify-center sm:flex-nowrap sm:overflow-x-auto sm:pb-2">
          {mockCategories.slice(0, 6).map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.id)}
              className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-medium transition-all duration-200 whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-200/50'
                  : 'bg-gray-100 text-gray-600 hover:bg-purple-50 hover:text-purple-600'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Mobile Menu Button (floating) */}
      <button
        onClick={() => setShowMobileSidebar(!showMobileSidebar)}
        className="fixed left-4 bottom-6 z-30 md:hidden w-12 h-12 bg-indigo-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-indigo-700 transition-all duration-200"
      >
        <Menu className="w-6 h-6" />
      </button>

      {/* Main Content - 直接显示 */}
      <main className="max-w-7xl mx-auto px-4 py-6 w-full">
          <div className="flex gap-6">
            {/* Mobile Sidebar Overlay */}
          {showMobileSidebar && (
            <div
              className="fixed inset-0 bg-black/50 z-40 md:hidden"
              onClick={() => setShowMobileSidebar(false)}
            />
          )}

          {/* Left Sidebar */}
          <div className={`
            ${showMobileSidebar ? 'fixed left-0 top-0 h-full w-72 z-50 transform translate-x-0' : 'hidden md:block'}
            md:static md:transform-none md:w-64 md:flex-shrink-0
          `}>
            <div className="bg-white h-full md:h-auto md:rounded-3xl shadow-lg border border-gray-100 p-5 md:sticky md:top-24 overflow-y-auto">
              {/* Mobile Close Button */}
              <div className="flex justify-between items-center mb-5 md:hidden">
                <span className="font-semibold text-gray-900 text-lg">资源分类</span>
                <button
                  onClick={() => setShowMobileSidebar(false)}
                  className="p-2 hover:bg-gray-100 rounded-xl transition-all duration-200"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-widest mb-4 px-3">资源分类</h3>
              <nav className="space-y-1.5">
                {mockCategories.map((category) => {
                  const subcategories = getSubCategories(category.id)
                  const isExpanded = expandedCategory === category.id
                  const isSelected = selectedCategory === category.id
                  
                  return (
                    <div key={category.id}>
                      <div className="flex items-center">
                        <button
                          onClick={() => handleCategoryClick(category.id)}
                          className={`flex-1 text-left px-4 py-2.5 rounded-2xl text-sm font-medium transition-all duration-200 flex items-center justify-between cursor-pointer ${
                            isSelected
                              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200/40'
                              : 'text-gray-900 hover:bg-gray-100'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <FolderOpen className={`w-4 h-4 ${isSelected ? 'text-white/90' : 'text-gray-500'}`} />
                            <span className={isSelected ? 'text-white' : 'text-gray-900'}>{category.name}</span>
                          </div>
                          {subcategories.length > 0 && (
                            <span
                              onClick={(e) => {
                                e.stopPropagation()
                                setExpandedCategory(isExpanded ? null : category.id)
                              }}
                              className={`ml-2 p-1 rounded-lg transition-all duration-200 ${isSelected ? 'hover:bg-white/20' : 'hover:bg-gray-100'}`}
                            >
                              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                            </span>
                          )}
                        </button>
                      </div>
                      
                      {/* 子分类 */}
                      {isExpanded && subcategories.length > 0 && (
                        <div className="mt-1.5 space-y-1">
                          <button
                            onClick={() => { setSelectedSubCategory(null); setCurrentPage(1) }}
                            className={`w-full text-left px-4 py-2 rounded-xl text-xs transition-all duration-200 cursor-pointer ${
                              selectedSubCategory === null
                                ? 'bg-indigo-50 text-indigo-600 font-medium'
                                : 'text-gray-500 hover:bg-gray-100 hover:text-gray-900'
                            }`}
                          >
                            全部
                          </button>
                          {subcategories.map(sc => (
                            <button
                              key={sc.id}
                              onClick={() => { 
                                setSelectedCategory(category.id)
                                setSelectedSubCategory(sc.id)
                                setCurrentPage(1) 
                              }}
                              className={`w-full text-left px-4 py-2 rounded-xl text-xs transition-all duration-200 cursor-pointer ${
                                selectedSubCategory === sc.id
                                  ? 'bg-indigo-50 text-indigo-600 font-medium'
                                  : 'text-gray-500 hover:bg-gray-100 hover:text-gray-900'
                              }`}
                            >
                              {sc.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })}
              </nav>
            </div>
          </div>

          {/* Right Content */}
          <div className="flex-1 min-w-0">
            {/* Featured */}
            {!selectedSubCategory && featuredLinks.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center gap-2.5 mb-5">
                  <div className="p-1.5 bg-amber-100 rounded-xl">
                    <Sparkles className="w-5 h-5 text-amber-500" />
                  </div>
                  <h2 className="text-xl font-bold text-gray-900">精选推荐</h2>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
                  {featuredLinks.map((link) => (
                    <div
                      key={link.id}
                      onClick={() => setSelectedLink(link)}
                      className="group bg-white border border-gray-100 hover:border-indigo-200 hover:shadow-lg hover:shadow-indigo-50 transition-all duration-300 cursor-pointer rounded-3xl p-5"
                    >
                      <div className="flex flex-col gap-3">
                        {getLinkIcon(link)}
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors text-sm truncate leading-tight">
                            {link.title}
                          </h3>
                          <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">{link.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Links List */}
            <div className="bg-white border border-gray-100 shadow-lg rounded-3xl">
              <div className="px-8 py-5 border-b border-gray-100/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-1.5 h-8 bg-gradient-to-b from-indigo-500 to-purple-500 rounded-full"></div>
                  <h2 className="text-xl font-bold text-gray-900">
                    {selectedSubCategory 
                      ? getSubCategories(selectedCategory || '').find(sc => sc.id === selectedSubCategory)?.name || '资源列表'
                      : selectedCategory 
                        ? mockCategories.find(c => c.id === selectedCategory)?.name 
                        : '全部资源'
                    }
                  </h2>
                  <span className="ml-3 px-3 py-1 bg-gray-100/80 rounded-full text-xs text-gray-500 font-medium">{filteredLinks.length} 个</span>
                </div>
                <div className="flex items-center bg-gray-100/80 rounded-xl p-1 gap-0.5">
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 rounded-lg transition-all duration-200 ${
                      viewMode === 'list'
                        ? 'bg-white text-indigo-600 shadow-sm'
                        : 'text-gray-500 hover:text-gray-900'
                    }`}
                    title="列表视图"
                  >
                    <List className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded-lg transition-all duration-200 ${
                      viewMode === 'grid'
                        ? 'bg-white text-indigo-600 shadow-sm'
                        : 'text-gray-500 hover:text-gray-900'
                    }`}
                    title="网格视图"
                  >
                    <Grid className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="p-6">
                {filteredLinks.length === 0 ? (
                  <div className="text-center py-20 text-gray-500">
                    <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
                      <FolderOpen className="w-10 h-10 text-gray-500" />
                    </div>
                    <p className="text-lg font-medium text-gray-900">暂无资源</p>
                    <p className="text-sm text-gray-500 mt-2">该分类下还没有添加资源</p>
                  </div>
                ) : (
                  <>
                    {viewMode === 'list' ? (
                      /* 列表视图 */
                      <div className="space-y-2.5">
                        {paginatedLinks.map((link, index) => (
                          <div
                            key={link.id}
                            className="group flex items-center gap-5 p-5 rounded-2xl hover:bg-gray-100 transition-all duration-200 border border-transparent hover:border-indigo-100 cursor-pointer"
                            onClick={() => setSelectedLink(link)}
                          >
                            {getLinkIcon(link)}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2.5">
                                <h3 className="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors truncate text-sm">
                                  {link.title}
                                </h3>
                                {link.is_pinned && (
                                  <span className="flex-shrink-0 px-2.5 py-0.5 bg-gradient-to-r from-amber-100 to-orange-100 text-amber-700 text-xs rounded-full font-medium flex items-center gap-1 shadow-sm">
                                    <Star className="w-3 h-3 fill-amber-500" /> 置顶
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-gray-500 truncate mt-1 leading-relaxed">{link.description}</p>
                              <div className="flex items-center mt-1.5 text-xs text-gray-500">
                                <span className="flex items-center gap-1.5">
                                  <Eye className="w-3.5 h-3.5" />
                                  {link.click_count?.toLocaleString()}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all duration-200">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  copyToClipboard(link.url, link.id)
                                }}
                                className="p-2.5 text-gray-500 hover:text-indigo-600 hover:bg-gray-100 rounded-xl transition-all duration-200 shadow-sm hover:shadow-md"
                                title="复制链接"
                              >
                                {copiedId === link.id ? (
                                  <Check className="w-5 h-5 text-green-500" />
                                ) : (
                                  <Copy className="w-5 h-5" />
                                )}
                              </button>
                              <a
                                href={link.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-2.5 text-gray-500 hover:text-indigo-600 hover:bg-gray-100 rounded-xl transition-all duration-200 shadow-sm hover:shadow-md"
                                title="访问链接"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <ExternalLink className="w-5 h-5" />
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      /* 网格视图 */
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                        {paginatedLinks.map((link, index) => (
                          <div
                            key={link.id}
                            onClick={() => setSelectedLink(link)}
                            className="group p-5 rounded-3xl border border-gray-200 hover:border-indigo-200 hover:shadow-lg hover:shadow-indigo-50 transition-all duration-300 cursor-pointer bg-white"
                          >
                            <div className="flex items-center gap-3 mb-4">
                              {getLinkIcon(link)}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <h3 className="font-semold text-gray-900 group-hover:text-indigo-600 transition-colors text-sm truncate">
                                    {link.title}
                                  </h3>
                                  {link.is_pinned && (
                                    <Star className="w-3.5 h-3.5 text-amber-500 flex-shrink-0 fill-amber-500" />
                                  )}
                                </div>
                                <p className="text-xs text-gray-500 truncate mt-1 leading-relaxed">{link.description}</p>
                              </div>
                            </div>
                            <div className="flex items-center text-xs text-gray-500">
                              <span className="flex items-center gap-1.5">
                                <Eye className="w-3.5 h-3.5" />
                                {link.click_count?.toLocaleString()}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* 分页控件 */}
                    {totalPages > 1 && (
                      <div className="flex items-center justify-center gap-2.5 mt-10">
                        <button
                          onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                          disabled={currentPage === 1}
                          className="px-5 py-2 rounded-xl text-sm border border-gray-300 hover:border-indigo-300 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-200 font-medium"
                        >
                          上一页
                        </button>
                        
                        {Array.from({ length: totalPages }, (_, i) => i + 1)
                          .filter(page => 
                            page === 1 || 
                            page === totalPages || 
                            Math.abs(page - currentPage) <= 2
                          )
                          .map((page, index, array) => (
                            <span key={page}>
                              {index > 0 && array[index - 1] !== page - 1 && (
                                <span className="px-2 text-gray-500">...</span>
                              )}
                              <button
                                onClick={() => setCurrentPage(page)}
                                className={`w-10 h-10 rounded-xl text-sm transition-all duration-200 ${
                                  currentPage === page
                                    ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-semibold shadow-md shadow-indigo-200/40'
                                    : 'border border-gray-300 hover:border-indigo-300 hover:bg-gray-100 text-gray-900'
                                }`}
                              >
                                {page}
                              </button>
                            </span>
                          ))
                        }
                        
                        <button
                          onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                          disabled={currentPage === totalPages}
                          className="px-5 py-2 rounded-xl text-sm border border-gray-300 hover:border-indigo-300 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-200 font-medium"
                        >
                          下一页
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* 链接详情弹窗 */}
      {selectedLink && (
        <div className="fixed inset-0 z-50 overflow-y-auto animate-fade-in">
          <div
            className="fixed inset-0 bg-black/60 transition-opacity duration-300"
            onClick={() => setSelectedLink(null)}
          />
          <div className="flex min-h-full items-center justify-center p-4 sm:p-6">
            <div className="relative bg-white rounded-2xl sm:rounded-3xl shadow-2xl max-w-lg w-full p-5 sm:p-8">
              <button
                onClick={() => setSelectedLink(null)}
                className="absolute right-4 top-4 p-2 hover:bg-gray-100 rounded-xl transition-all duration-200"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>

              <div className="flex items-start gap-5 mb-6">
                {getLinkIcon(selectedLink)}
                <div className="flex-1 min-w-0">
                  <h3 className="text-xl font-bold text-gray-900 mb-2 leading-tight">{selectedLink.title}</h3>
                  {selectedLink.is_pinned && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-amber-100 to-orange-100 text-amber-700 text-xs rounded-full font-medium shadow-sm">
                      <Star className="w-3.5 h-3.5 fill-amber-500" /> 置顶推荐
                    </span>
                  )}
                </div>
              </div>

              {selectedLink.description && (
                <p className="text-sm text-gray-500 mb-6 leading-relaxed">{selectedLink.description}</p>
              )}

              <div className="flex flex-wrap gap-2.5 mb-6">
                <span className="px-3.5 py-1.5 bg-gray-100/80 text-gray-600 text-xs rounded-xl font-medium">
                  <span className="mr-1">📁</span>
                  {mockCategories.find(c => c.id === selectedLink.category_id)?.name || '未分类'}
                </span>
                {selectedLink.subcategory_id && (
                  <span className="px-3.5 py-1.5 bg-indigo-50/80 text-indigo-600 text-xs rounded-xl font-medium">
                    <span className="mr-1">📂</span>
                    {mockSubCategories.find(sc => sc.id === selectedLink.subcategory_id)?.name}
                  </span>
                )}
              </div>

              {selectedLink.extract_code && (
                <div className="mb-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200/50 shadow-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-amber-700 font-semibold">🔑 提取码：</span>
                    <span className="text-lg font-mono font-bold text-amber-800 tracking-wider">{selectedLink.extract_code}</span>
                  </div>
                </div>
              )}

              <div className="flex items-center mb-8 text-sm text-gray-400">
                <span className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  <span className="font-medium">{selectedLink.click_count?.toLocaleString()}</span>
                </span>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => copyToClipboard(selectedLink.url, selectedLink.id)}
                  className="flex-1 h-11 flex items-center justify-center gap-2 bg-black/5 hover:bg-black/10 active:bg-black/15 rounded-xl transition-all duration-200 font-medium text-sm cursor-pointer"
                >
                  {copiedId === selectedLink.id ? (
                    <>
                      <Check className="w-4 h-4 text-green-600" />
                      <span className="text-green-600">已复制</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-gray-600" />
                      <span className="text-gray-700">复制链接</span>
                    </>
                  )}
                </button>
                <a
                  href={selectedLink.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 h-11 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-xl transition-all duration-200 font-medium text-sm cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>访问链接</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 py-10 mt-12">
        <div className="max-w-7xl mx-auto px-4">
          {/* Disclaimer */}
          <div className="text-center mb-6 max-w-4xl mx-auto">
            <p className="text-xs text-gray-400 leading-relaxed">
              免责申明：本站不以盈利为目的，下载资源均来源于网络，只做学习和交流使用，版权归原作者所有，若作商业用途请购买正版，由于未及时购买和付费发生的侵权行为，与本站无关。如果侵犯了您的合法权益，请联系站长删除。
            </p>
          </div>
          {/* Divider */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent flex-1"></div>
            <div className="w-2 h-2 bg-indigo-400 rounded-full"></div>
            <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent flex-1"></div>
          </div>
          {/* Copyright */}
          <div className="flex items-center justify-center gap-3 text-sm text-gray-400">
            <Link 
              to="/admin-login" 
              className="w-8 h-8 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-xl flex items-center justify-center hover:shadow-lg cursor-pointer shadow-md shadow-indigo-200/40"
              title="进入后台管理"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4 text-white" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </Link>
            <span className="font-medium">资源云</span>
            <span className="text-gray-300">·</span>
            <span>© 2026</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
