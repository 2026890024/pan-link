import { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import {
  Download,
  Upload,
  FileText,
  FileJson,
  Table,
  Eye,
  Calendar,
  RefreshCw,
  Trash2,
  Share2,
  Link2,
  CheckCircle,
  AlertCircle,
} from 'lucide-react'
import { mockLinks } from '@/data/mock'
import { formatNumber, formatDate } from '@/lib/utils'
import toast from 'react-hot-toast'

type ExportFormat = 'csv' | 'json' | 'excel'
type Tab = 'export' | 'import' | 'share'

export default function DataManagementPage() {
  const [activeTab, setActiveTab] = useState<Tab>('export')
  const [exportFormat, setExportFormat] = useState<ExportFormat>('csv')
  const [selectedForExport, setSelectedForExport] = useState<string[]>([])
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [importPreview, setImportPreview] = useState<any[] | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const tabs = [
    { id: 'export' as Tab, label: '数据导出', icon: Download },
    { id: 'import' as Tab, label: '数据导入', icon: Upload },
    { id: 'share' as Tab, label: '分享管理', icon: Share2 },
  ]

  const formatOptions = [
    { id: 'csv' as ExportFormat, label: 'CSV', icon: FileText, desc: '适合 Excel 打开' },
    { id: 'json' as ExportFormat, label: 'JSON', icon: FileJson, desc: '适合程序处理' },
    { id: 'excel' as ExportFormat, label: 'Excel', icon: Table, desc: '带格式的表格文件' },
  ]

  const handleExport = async () => {
    setIsExporting(true)
    
    // 模拟导出过程
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const dataToExport = selectedForExport.length > 0
      ? mockLinks.filter((l) => selectedForExport.includes(l.id))
      : mockLinks

    let content = ''
    let filename = ''
    let mimeType = ''

    if (exportFormat === 'csv') {
      // CSV 格式
      const headers = ['名称', 'Slug', '链接', '提取码', '分类', '点击量', '转化量', '有效期', '创建时间']
      const rows = dataToExport.map((l) => [
        l.name,
        l.slug,
        l.url,
        l.extract_code || '',
        l.category_name || '',
        l.click_count,
        l.registration_count,
        l.validity_period,
        formatDate(l.created_at),
      ])
      content = [headers, ...rows].map((row) => row.join(',')).join('\n')
      filename = `links_export_${Date.now()}.csv`
      mimeType = 'text/csv'
    } else if (exportFormat === 'json') {
      content = JSON.stringify(dataToExport, null, 2)
      filename = `links_export_${Date.now()}.json`
      mimeType = 'application/json'
    } else {
      // Excel 格式 (实际项目中建议使用 xlsx 库)
      content = JSON.stringify(dataToExport)
      filename = `links_export_${Date.now()}.xlsx`
      mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    }

    // 创建下载
    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    setIsExporting(false)
    toast.success(`已导出 ${dataToExport.length} 条数据`)
  }

  const handleImportClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsImporting(true)

    // 模拟文件解析
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // 模拟预览数据
    setImportPreview([
      { name: '示例链接 1', url: 'https://example.com/1', extract_code: '1234' },
      { name: '示例链接 2', url: 'https://example.com/2', extract_code: '5678' },
      { name: '示例链接 3', url: 'https://example.com/3', extract_code: 'abcd' },
    ])

    setIsImporting(false)
    toast.success('文件解析成功，请预览确认')
  }

  const handleConfirmImport = () => {
    toast.success('数据导入成功')
    setImportPreview(null)
  }

  const handleCancelImport = () => {
    setImportPreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  // 分享链接管理
  const [shareLinks, setShareLinks] = useState([
    { id: '1', name: '热门资源合集', slug: 'hot-2024', visits: 1256, createdAt: '2024-01-15' },
    { id: '2', name: '软件工具包', slug: 'tools', visits: 892, createdAt: '2024-02-20' },
    { id: '3', name: '教程资料集', slug: 'tutorials', visits: 543, createdAt: '2024-03-10' },
  ])
  const [showCreateShare, setShowCreateShare] = useState(false)
  const [newShareName, setNewShareName] = useState('')
  const [newShareSlug, setNewShareSlug] = useState('')

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">数据管理</h1>
        <p className="text-gray-500 mt-1">导入导出数据，管理分享链接</p>
      </div>

      {/* Tab 切换 */}
      <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
        <div className="flex border-b">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-6 py-4 flex items-center justify-center gap-2 font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-6">
          {/* 数据导出 */}
          {activeTab === 'export' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-6"
            >
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">选择导出格式</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  {formatOptions.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => setExportFormat(option.id)}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        exportFormat === option.id
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <option.icon className={`w-8 h-8 mx-auto mb-2 ${
                        exportFormat === option.id ? 'text-blue-600' : 'text-gray-400'
                      }`} />
                      <p className="font-medium text-gray-800">{option.label}</p>
                      <p className="text-sm text-gray-500 mt-1">{option.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">选择导出范围</h3>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 p-4 rounded-lg border cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="exportRange"
                      checked={selectedForExport.length === 0}
                      onChange={() => setSelectedForExport([])}
                      className="w-4 h-4 text-blue-600"
                    />
                    <div>
                      <p className="font-medium text-gray-800">导出全部</p>
                      <p className="text-sm text-gray-500">共 {mockLinks.length} 条数据</p>
                    </div>
                  </label>
                  <label className="flex items-center gap-3 p-4 rounded-lg border cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="exportRange"
                      checked={selectedForExport.length > 0}
                      onChange={() => setSelectedForExport([mockLinks[0].id])}
                      className="w-4 h-4 text-blue-600"
                    />
                    <div>
                      <p className="font-medium text-gray-800">导出选中项</p>
                      <p className="text-sm text-gray-500">
                        {selectedForExport.length > 0
                          ? `已选择 ${selectedForExport.length} 条数据`
                          : '请先选择要导出的链接'}
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              <button
                onClick={handleExport}
                disabled={isExporting}
                className="px-6 py-3 gradient-primary text-white rounded-lg font-medium hover:shadow-lg transition-shadow flex items-center gap-2 disabled:opacity-50"
              >
                {isExporting ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    导出中...
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5" />
                    开始导出
                  </>
                )}
              </button>
            </motion.div>
          )}

          {/* 数据导入 */}
          {activeTab === 'import' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-6"
            >
              {!importPreview ? (
                <>
                  <div
                    onClick={handleImportClick}
                    className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all"
                  >
                    <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <p className="text-lg font-medium text-gray-700 mb-2">
                      点击上传文件
                    </p>
                    <p className="text-sm text-gray-500">
                      支持 CSV、JSON、Excel 格式
                    </p>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv,.json,.xlsx,.xls"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-medium text-gray-800 mb-2">导入说明</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• CSV 文件需包含以下列：名称、链接、提取码（可选）</li>
                      <li>• JSON 文件需为对象数组格式</li>
                      <li>• Excel 文件第一行为表头</li>
                      <li>• 单次导入最大支持 1000 条数据</li>
                    </ul>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">文件解析成功，预览如下：</span>
                  </div>

                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">名称</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">链接</th>
                          <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">提取码</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {importPreview.map((item, index) => (
                          <tr key={index}>
                            <td className="px-4 py-2 text-sm text-gray-800">{item.name}</td>
                            <td className="px-4 py-2 text-sm text-gray-600">{item.url}</td>
                            <td className="px-4 py-2 text-sm text-gray-600">{item.extract_code}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={handleConfirmImport}
                      className="px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700"
                    >
                      确认导入
                    </button>
                    <button
                      onClick={handleCancelImport}
                      className="px-6 py-2 border rounded-lg hover:bg-gray-50"
                    >
                      取消
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {/* 分享管理 */}
          {activeTab === 'share' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">分享短链接</h3>
                <button 
                  onClick={() => setShowCreateShare(true)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  创建分享
                </button>
              </div>

              <div className="space-y-3">
                {shareLinks.map((link) => (
                  <div
                    key={link.id}
                    className="p-4 rounded-xl border hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-gray-800">{link.name}</h4>
                        <p className="text-sm text-blue-600 mt-1">
                          {window.location.origin}/s/{link.slug}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="p-2 hover:bg-gray-100 rounded-lg" title="复制链接">
                          <Link2 className="w-4 h-4 text-gray-500" />
                        </button>
                        <button className="p-2 hover:bg-gray-100 rounded-lg" title="编辑">
                          <Eye className="w-4 h-4 text-gray-500" />
                        </button>
                        <button className="p-2 hover:bg-red-50 rounded-lg" title="删除">
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {formatNumber(link.visits)} 次访问
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {link.createdAt}
                      </span>
                    </div>
                  </div>
                  ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* 创建分享弹窗 */}
      {showCreateShare && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/50"
            onClick={() => setShowCreateShare(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6"
          >
            <h3 className="text-lg font-bold text-gray-900 mb-4">创建分享</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">分享名称</label>
                <input
                  type="text"
                  value={newShareName}
                  onChange={(e) => setNewShareName(e.target.value)}
                  placeholder="例如：热门资源合集"
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:border-indigo-300"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">短链接后缀</label>
                <input
                  type="text"
                  value={newShareSlug}
                  onChange={(e) => setNewShareSlug(e.target.value)}
                  placeholder="例如：hot-2024"
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:border-indigo-300"
                />
                <p className="text-xs text-gray-400 mt-1">分享链接：{window.location.origin}/s/{newShareSlug || 'xxx'}</p>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  if (!newShareName || !newShareSlug) {
                    toast.error('请填写完整信息')
                    return
                  }
                  const newShare = {
                    id: Date.now().toString(),
                    name: newShareName,
                    slug: newShareSlug,
                    visits: 0,
                    createdAt: new Date().toISOString().split('T')[0]
                  }
                  setShareLinks(prev => [...prev, newShare])
                  setShowCreateShare(false)
                  setNewShareName('')
                  setNewShareSlug('')
                  toast.success('分享创建成功')
                }}
                className="flex-1 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-medium"
              >
                创建
              </button>
              <button
                onClick={() => setShowCreateShare(false)}
                className="flex-1 py-2.5 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium"
              >
                取消
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  )
}
