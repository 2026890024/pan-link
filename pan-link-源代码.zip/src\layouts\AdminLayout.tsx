import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  Link2,
  User,
  Database,
  LogOut,
  Menu,
  X,
  ChevronRight,
  FolderOpen,
  HardDrive,
  BarChart3,
} from 'lucide-react'
import { useState } from 'react'
import { cn } from '@/lib/utils'

const navItems = [
  { path: '/admin/resources', label: '资源管理', icon: Link2 },
  { path: '/admin/drive-types', label: '网盘类型', icon: HardDrive },
  { path: '/admin/dashboard', label: '仪表盘', icon: LayoutDashboard },
  { path: '/admin/profile', label: '个人中心', icon: User },
  { path: '/admin/data', label: '数据管理', icon: Database },
  { path: '/admin/homepage-settings', label: '首页设置', icon: LayoutDashboard },
]

export default function AdminLayout() {
  const location = useLocation()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false)

  const isActive = (path: string) => {
    if (path === '/admin/resources') {
      return location.pathname === '/admin' || location.pathname === '/admin/resources'
    }
    return location.pathname === path
  }

  return (
    <div className="min-h-screen bg-gray-50/80">
      {/* 移动端遮罩 */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        />
      )}

      {/* 侧边栏 */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full bg-white border-r border-gray-100 transition-all duration-300',
          sidebarOpen ? 'w-64' : 'w-20',
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Logo */}
        <div className="flex items-center h-16 px-5 border-b border-gray-100">
          <Link to="/admin" className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <Link2 className="w-5 h-5 text-white" />
            </div>
            {sidebarOpen && (
              <span className="font-semibold text-gray-800 text-base">管理后台</span>
            )}
          </Link>
          <button
            className="ml-auto p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-all duration-200 hidden lg:block"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>

        {/* 导航 */}
        <nav className="p-3 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                'flex items-center gap-3 px-4 py-2.5 rounded-2xl transition-all duration-200',
                isActive(item.path)
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
              )}
              onClick={() => setMobileSidebarOpen(false)}
            >
              <item.icon className="w-[18px] h-[18px] flex-shrink-0" />
              {sidebarOpen && <span className="font-medium text-sm">{item.label}</span>}
            </Link>
          ))}
        </nav>

        {/* 底部 */}
        <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-gray-100">
          <Link
            to="/"
            className="flex items-center gap-3 px-4 py-2.5 rounded-2xl text-gray-500 hover:bg-gray-50 hover:text-gray-700 transition-all duration-200"
          >
            <LogOut className="w-[18px] h-[18px] flex-shrink-0" />
            {sidebarOpen && <span className="font-medium text-sm">返回前台</span>}
          </Link>
        </div>
      </aside>

      {/* 主内容区 */}
      <div
        className={cn(
          'min-h-screen transition-all duration-300',
          sidebarOpen ? 'lg:ml-64' : 'lg:ml-20'
        )}
      >
        {/* 顶部栏 */}
        <header className="sticky top-0 z-30 h-16 bg-white/90 backdrop-blur-xl border-b border-gray-100 flex items-center px-6 gap-4">
          <button
            className="lg:hidden p-2 rounded-xl hover:bg-gray-100 text-gray-500 transition-all duration-200"
            onClick={() => setMobileSidebarOpen(true)}
          >
            <Menu className="w-6 h-6" />
          </button>

          {/* 面包屑 */}
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-400">后台</span>
            {location.pathname !== '/admin' && (
              <>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
                <span className="text-gray-700 font-medium">
                  {navItems.find((item) => isActive(item.path))?.label}
                </span>
              </>
            )}
          </div>
        </header>

        {/* 内容 */}
        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
