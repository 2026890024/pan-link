import { Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'

// 前台页面
import LinkDetailPage from '@/pages/frontend/LinkDetailPage'
import CategoryPage from '@/pages/frontend/CategoryPage'
import SearchPage from '@/pages/frontend/SearchPage'
import HomePage from '@/pages/frontend/HomePage'

// 认证页面
import AdminLoginPage from '@/pages/auth/AdminLoginPage'

// 后台页面
import DashboardPage from '@/pages/admin/DashboardPage'
import ResourceManagementPage from '@/pages/admin/ResourceManagementPage'
import DriveTypeManagementPage from '@/pages/admin/DriveTypeManagementPage'
import ProfilePage from '@/pages/admin/ProfilePage'
import DataManagementPage from '@/pages/admin/DataManagementPage'
import HomepageSettingsPage from '@/pages/admin/HomepageSettingsPage'
import AdminLayout from '@/layouts/AdminLayout'
import PublicLayout from '@/layouts/PublicLayout'

function App() {
  return (
    <>
      <Toaster position="top-center" />
      <Routes>
        {/* 前台公开路由 */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/s/:slug" element={<LinkDetailPage />} />
          <Route path="/category/:id" element={<CategoryPage />} />
          <Route path="/search" element={<SearchPage />} />
        </Route>

        {/* 管理后台登录 */}
        <Route path="/admin-login" element={<AdminLoginPage />} />

        {/* 后台管理路由 */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<ResourceManagementPage />} />
          <Route path="resources" element={<ResourceManagementPage />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="drive-types" element={<DriveTypeManagementPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="data" element={<DataManagementPage />} />
          <Route path="homepage-settings" element={<HomepageSettingsPage />} />
        </Route>
      </Routes>
    </>
  )
}

export default App
