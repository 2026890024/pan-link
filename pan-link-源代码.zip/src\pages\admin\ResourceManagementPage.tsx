import { useState, useRef } from 'react'
import {
  Plus,
  Edit2,
  Trash2,
  Star,
  Pin,
  Eye,
  Copy,
  Check,
  ExternalLink,
  Search,
  FolderOpen,
  Save,
  X,
  ChevronDown,
  ChevronRight,
  List,
  Grid,
  HardDrive,
  Upload,
  Image as ImageIcon,
} from 'lucide-react'
import { mockLinks, mockCategories, driveTypes, mockSubCategories } from '@/data/mock'

export default function ResourceManagementPage() {
  const [categories, setCategories] = useState(mockCategories)
  const [subCategories, setSubCategories] = useState(mockSubCategories)
  const [links, setLinks] = useState(mockLinks)
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null)
  const [expandedCategories, setExpandedCategories] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list')
  
  // 分类编辑状态
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null)
  const [editCategoryName, setEditCategoryName] = useState('')
  const [isAddingCategory, setIsAddingCategory] = useState(false)
  const [newCategoryName, setNewCategoryName] = useState('')
  
  // 子分类编辑状态
  const [editingSubCategoryId, setEditingSubCategoryId] = useState<string | null>(null)
  const [editSubCategoryName, setEditSubCategoryName] = useState('')
  const [isAddingSubCategory, setIsAddingSubCategory] = useState(false)
  const [newSubCategoryName, setNewSubCategoryName] = useState('')
  const [newSubCategoryParentId, setNewSubCategoryParentId] = useState<string>('')
  
  // 链接编辑状态
  const [isAddingLink, setIsAddingLink] = useState(false)
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null)
  const [newLink, setNewLink] = useState({
    title: '',
    url: '',
    description: '',
    category_id: '',
    subcategory_id: '',
    drive_type: 'baidu',
    slug: '',
    icon: '',
    extract_code: '',
    expires_at: '',
  })
  const [editingLink, setEditingLink] = useState({
    id: '',
    title: '',
    url: '',
    description: '',
    category_id: '',
    subcategory_id: '',
    drive_type: 'baidu',
    slug: '',
    icon: '',
    extract_code: '',
    expires_at: '',
  })
  const [newLinkIcon, setNewLinkIcon] = useState<string>('')
  const [editingLinkIcon, setEditingLinkIcon] = useState<string>('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [copiedId, setCopiedId] = useState<string | null>(null)

  // 切换分类展开/收起
  const toggleExpand = (id: string) => {
    setExpandedCategories(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  // 获取当前分类的链接数量
  const getCategoryLinkCount = (categoryId: string) => {
    return links.filter(l => l.category_id === categoryId).length
  }

  // 获取过滤后的链接
  const getFilteredLinks = () => {
    return links.filter(link => {
      const matchesCategory = !selectedCategoryId || link.category_id === selectedCategoryId
      const matchesSearch = !searchQuery || 
        link.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        link.description.toLowerCase().includes(searchQuery.toLowerCase())
      return matchesCategory && matchesSearch
    })
  }

  // 获取链接的显示图标
  const getLinkDisplayIcon = (link: (typeof mockLinks)[0]) => {
    // 如果有自定义图标，显示自定义图标
    if (link.icon) {
      return (
        <img 
          src={link.icon} 
          alt={link.title}
          className="w-10 h-10 rounded-xl object-cover flex-shrink-0 shadow"
        />
      )
    }
    
    // 否则显示网盘类型图标
    const colors: Record<string, string> = {
      baidu: 'bg-gradient-to-br from-blue-500 to-blue-600',
      quark: 'bg-gradient-to-br from-purple-500 to-purple-600',
      aliyun: 'bg-gradient-to-br from-red-500 to-orange-500',
      lanzou: 'bg-gradient-to-br from-orange-500 to-amber-500',
      xunlei: 'bg-gradient-to-br from-cyan-500 to-blue-500',
    }
    const names: Record<string, string> = {
      baidu: '百度',
      quark: '夸克',
      aliyun: '阿里',
      lanzou: '蓝奏',
      xunlei: '迅雷',
    }
    return (
      <div className={`w-10 h-10 rounded-xl ${colors[link.drive_type] || 'bg-gray-500'} flex items-center justify-center text-white font-bold text-xs flex-shrink-0 shadow`}>
        {names[link.drive_type] || '网'}
      </div>
    )
  }

  // 分类操作
  const handleAddCategory = () => {
    if (newCategoryName.trim()) {
      setCategories([...categories, {
        id: Date.now().toString(),
        name: newCategoryName.trim(),
        icon: 'folder',
        sort_order: categories.length + 1
      }])
      setNewCategoryName('')
      setIsAddingCategory(false)
    }
  }

  const handleSaveCategory = () => {
    if (editingCategoryId && editCategoryName.trim()) {
      setCategories(categories.map(c => 
        c.id === editingCategoryId ? { ...c, name: editCategoryName.trim() } : c
      ))
      setEditingCategoryId(null)
    }
  }

  const handleDeleteCategory = (id: string) => {
    if (confirm('确定删除该分类吗？该分类下的所有链接也会被删除。')) {
      setCategories(categories.filter(c => c.id !== id))
      setLinks(links.filter(l => l.category_id !== id))
      if (selectedCategoryId === id) setSelectedCategoryId(null)
    }
  }

  // 子分类操作
  const handleAddSubCategory = () => {
    if (newSubCategoryName.trim() && newSubCategoryParentId) {
      setSubCategories([...subCategories, {
        id: Date.now().toString(),
        category_id: newSubCategoryParentId,
        name: newSubCategoryName.trim(),
        sort_order: subCategories.filter(sc => sc.category_id === newSubCategoryParentId).length + 1
      }])
      setNewSubCategoryName('')
      setIsAddingSubCategory(false)
      setNewSubCategoryParentId('')
    }
  }

  const handleSaveSubCategory = () => {
    if (editingSubCategoryId && editSubCategoryName.trim()) {
      setSubCategories(subCategories.map(sc => 
        sc.id === editingSubCategoryId ? { ...sc, name: editSubCategoryName.trim() } : sc
      ))
      setEditingSubCategoryId(null)
    }
  }

  const handleDeleteSubCategory = (id: string) => {
    if (confirm('确定删除该子分类吗？')) {
      setSubCategories(subCategories.filter(sc => sc.id !== id))
      // 同时更新链接的子分类ID
      setLinks(links.map(l => l.subcategory_id === id ? { ...l, subcategory_id: '' } : l))
    }
  }

  // 获取分类的子分类
  const getCategorySubCategories = (categoryId: string) => {
    return subCategories.filter(sc => sc.category_id === categoryId)
  }

  // 图标上传
  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    // 检查文件类型
    if (!file.type.startsWith('image/')) {
      alert('请上传图片文件')
      return
    }
    
    // 检查文件大小（限制 2MB）
    if (file.size > 2 * 1024 * 1024) {
      alert('图片大小不能超过 2MB')
      return
    }
    
    const reader = new FileReader()
    reader.onload = (e) => {
      const base64 = e.target?.result as string
      setNewLinkIcon(base64)
    }
    reader.readAsDataURL(file)
  }

  const removeIcon = () => {
    setNewLinkIcon('')
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  // 链接操作
  const copyToClipboard = async (url: string, id: string) => {
    try {
      await navigator.clipboard.writeText(url)
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), 2000)
    } catch (err) {
      console.error('复制失败:', err)
    }
  }

  const togglePin = (id: string) => {
    setLinks(links.map(l => l.id === id ? { ...l, is_pinned: !l.is_pinned } : l))
  }

  const toggleFeatured = (id: string) => {
    setLinks(links.map(l => l.id === id ? { ...l, is_featured: !l.is_featured } : l))
  }

  const handleDeleteLink = (id: string) => {
    if (confirm('确定删除该链接吗？')) {
      setLinks(links.filter(l => l.id !== id))
    }
  }

  const handleAddLink = () => {
    if (newLink.title.trim() && newLink.url.trim()) {
      const targetCategoryId = newLink.category_id || categories[0]?.id || ''
      setLinks([{
        id: Date.now().toString(),
        ...newLink,
        category_id: targetCategoryId,
        subcategory_id: newLink.subcategory_id || '',
        icon: newLinkIcon || '',
        slug: newLink.slug || newLink.title.slice(0, 10).replace(/\s/g, '-').toLowerCase(),
        click_count: 0,
        created_at: new Date().toISOString(),
        is_pinned: false,
        is_featured: false,
      }, ...links])
      setNewLink({ title: '', url: '', description: '', category_id: '', subcategory_id: '', drive_type: 'baidu', slug: '', icon: '', extract_code: '', expires_at: '' })
      setNewLinkIcon('')
      if (fileInputRef.current) fileInputRef.current.value = ''
      setIsAddingLink(false)
    }
  }

  // 开始编辑链接
  const startEdit = (link: typeof mockLinks[0]) => {
    setEditingLinkId(link.id)
    setEditingLink({
      id: link.id,
      title: link.title,
      url: link.url,
      description: link.description || '',
      category_id: link.category_id,
      subcategory_id: link.subcategory_id || '',
      drive_type: link.drive_type,
      slug: link.slug || '',
      icon: link.icon || '',
      extract_code: link.extract_code || '',
      expires_at: link.expires_at || '',
    })
    setEditingLinkIcon(link.icon || '')
    setIsAddingLink(false)
  }

  // 保存编辑
  const handleEdit = () => {
    if (editingLink.id && editingLink.title.trim() && editingLink.url.trim()) {
      setLinks(links.map(l => l.id === editingLink.id ? {
        ...l,
        ...editingLink,
        icon: editingLinkIcon || '',
      } : l))
      setEditingLinkId(null)
      setEditingLink({ id: '', title: '', url: '', description: '', category_id: '', subcategory_id: '', drive_type: 'baidu', slug: '', icon: '', extract_code: '', expires_at: '' })
      setEditingLinkIcon('')
    }
  }

  // 取消编辑
  const cancelEdit = () => {
    setEditingLinkId(null)
    setEditingLink({ id: '', title: '', url: '', description: '', category_id: '', subcategory_id: '', drive_type: 'baidu', slug: '', icon: '', extract_code: '', expires_at: '' })
    setEditingLinkIcon('')
  }

  const getDriveIcon = (type: string) => {
    const colors: Record<string, string> = {
      baidu: 'bg-gradient-to-br from-blue-500 to-blue-600',
      quark: 'bg-gradient-to-br from-purple-500 to-purple-600',
      aliyun: 'bg-gradient-to-br from-red-500 to-orange-500',
      lanzou: 'bg-gradient-to-br from-orange-500 to-amber-500',
      xunlei: 'bg-gradient-to-br from-cyan-500 to-blue-500',
    }
    const names: Record<string, string> = {
      baidu: '百度',
      quark: '夸克',
      aliyun: '阿里',
      lanzou: '蓝奏',
      xunlei: '迅雷',
    }
    return (
      <div className={`w-10 h-10 rounded-lg ${colors[type] || 'bg-gray-500'} flex items-center justify-center text-white font-bold text-xs flex-shrink-0 shadow`}>
        {names[type] || '网'}
      </div>
    )
  }

  const filteredLinks = getFilteredLinks()

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">资源管理</h1>
          <p className="text-gray-500 mt-1">统一管理分类与链接</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAddingLink(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-medium"
          >
            <Plus className="w-5 h-5" />
            添加链接
          </button>
          <button
            onClick={() => setIsAddingCategory(true)}
            className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors font-medium"
          >
            <FolderOpen className="w-5 h-5" />
            添加分类
          </button>
        </div>
      </div>

      <div className="flex gap-6">
        {/* 左侧分类列表 */}
        <div className="w-72 flex-shrink-0">
          {/* 添加分类表单 */}
          {isAddingCategory && (
            <div className="bg-white rounded-2xl border border-gray-200 p-4 mb-4">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="分类名称"
                  className="flex-1 px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 text-sm"
                  autoFocus
                  onKeyDown={(e) => e.key === 'Enter' && handleAddCategory()}
                />
                <button onClick={handleAddCategory} className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                  <Save className="w-4 h-4" />
                </button>
                <button onClick={() => { setIsAddingCategory(false); setNewCategoryName(''); }} className="p-2 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* 分类列表 */}
          <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
            <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
              <h3 className="font-medium text-gray-700 text-sm">分类列表</h3>
            </div>
            
            {/* 全部资源 */}
            <button
              onClick={() => setSelectedCategoryId(null)}
              className={`w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-100 ${
                !selectedCategoryId ? 'bg-blue-50 text-blue-600' : 'text-gray-700'
              }`}
            >
              <span className="font-medium">全部资源</span>
              <span className="text-sm opacity-60">{links.length}</span>
            </button>

            {/* 分类项 */}
            {categories.map((category) => {
              const isExpanded = expandedCategories.includes(category.id)
              const isSelected = selectedCategoryId === category.id
              const linkCount = getCategoryLinkCount(category.id)
              const categorySubCategories = getCategorySubCategories(category.id)
              
              return (
                <div key={category.id} className="border-b border-gray-100 last:border-0">
                  <div className={`flex items-center px-4 py-2 hover:bg-gray-50 transition-colors ${
                    isSelected ? 'bg-blue-50' : ''
                  }`}>
                    <button
                      onClick={() => toggleExpand(category.id)}
                      className="p-1 hover:bg-gray-100 rounded"
                    >
                      {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </button>
                    
                    {editingCategoryId === category.id ? (
                      <div className="flex-1 flex items-center gap-2 ml-1">
                        <input
                          type="text"
                          value={editCategoryName}
                          onChange={(e) => setEditCategoryName(e.target.value)}
                          className="flex-1 px-2 py-1 border border-gray-200 rounded focus:outline-none focus:ring-1 focus:ring-indigo-200 text-sm"
                          autoFocus
                          onKeyDown={(e) => e.key === 'Enter' && handleSaveCategory()}
                        />
                        <button onClick={handleSaveCategory} className="p-1 text-green-600 hover:bg-green-50 rounded">
                          <Save className="w-4 h-4" />
                        </button>
                        <button onClick={() => setEditingCategoryId(null)} className="p-1 text-gray-400 hover:bg-gray-100 rounded">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          onClick={() => { setSelectedCategoryId(category.id); toggleExpand(category.id); }}
                          className={`flex-1 flex items-center gap-2 ml-1 text-left ${isSelected ? 'text-blue-600' : 'text-gray-700'}`}
                        >
                          <FolderOpen className="w-4 h-4" />
                          <span className="text-sm font-medium truncate">{category.name}</span>
                        </button>
                        <span className="text-xs text-gray-400 mx-2">{linkCount}</span>
                        <button
                          onClick={() => { setEditingCategoryId(category.id); setEditCategoryName(category.name); }}
                          className="p-1 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteCategory(category.id)}
                          className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                  
                  {/* 展开时显示子分类 */}
                  {isExpanded && (
                    <div className="pl-8 pr-4 pb-2">
                      {/* 子分类列表 */}
                      {categorySubCategories.map(sc => (
                        <div key={sc.id} className="flex items-center py-1 group/sc">
                          {editingSubCategoryId === sc.id ? (
                            <div className="flex-1 flex items-center gap-1">
                              <input
                                type="text"
                                value={editSubCategoryName}
                                onChange={(e) => setEditSubCategoryName(e.target.value)}
                                className="flex-1 px-2 py-0.5 border border-gray-200 rounded text-xs focus:outline-none focus:ring-1 focus:ring-indigo-200"
                                autoFocus
                                onKeyDown={(e) => e.key === 'Enter' && handleSaveSubCategory()}
                              />
                              <button onClick={handleSaveSubCategory} className="p-0.5 text-green-600 hover:bg-green-50 rounded">
                                <Save className="w-3 h-3" />
                              </button>
                              <button onClick={() => setEditingSubCategoryId(null)} className="p-0.5 text-gray-400 hover:bg-gray-100 rounded">
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <>
                              <button
                                onClick={() => {
                                  setSelectedCategoryId(category.id)
                                  // 可以按子分类筛选链接
                                }}
                                className="flex-1 text-left text-xs text-gray-600 hover:text-indigo-600 py-0.5"
                              >
                                {sc.name}
                              </button>
                              <button
                                onClick={() => { setEditingSubCategoryId(sc.id); setEditSubCategoryName(sc.name); }}
                                className="p-0.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded opacity-0 group-hover/sc:opacity-100"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => handleDeleteSubCategory(sc.id)}
                                className="p-0.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded opacity-0 group-hover/sc:opacity-100"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </>
                          )}
                        </div>
                      ))}
                      
                      {/* 添加子分类表单 */}
                      {isAddingSubCategory && newSubCategoryParentId === category.id ? (
                        <div className="flex items-center gap-1 mt-1">
                          <input
                            type="text"
                            value={newSubCategoryName}
                            onChange={(e) => setNewSubCategoryName(e.target.value)}
                            placeholder="子分类名称"
                            className="flex-1 px-2 py-0.5 border border-gray-200 rounded text-xs focus:outline-none focus:ring-1 focus:ring-indigo-200"
                            autoFocus
                            onKeyDown={(e) => e.key === 'Enter' && handleAddSubCategory()}
                          />
                          <button onClick={handleAddSubCategory} className="p-0.5 bg-indigo-600 text-white rounded hover:bg-indigo-700">
                            <Save className="w-3 h-3" />
                          </button>
                          <button onClick={() => { setIsAddingSubCategory(false); setNewSubCategoryName(''); setNewSubCategoryParentId(''); }} className="p-0.5 border border-gray-200 rounded hover:bg-gray-50">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => { setIsAddingSubCategory(true); setNewSubCategoryParentId(category.id); }}
                          className="text-xs text-indigo-600 hover:text-indigo-800 py-1 mt-1"
                        >
                          + 添加子分类
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* 右侧链接列表 */}
        <div className="flex-1">
          {/* 添加链接表单 */}
          {isAddingLink && (
            <div className="bg-white rounded-2xl border border-gray-200 p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-4">添加新链接</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">标题 *</label>
                  <input
                    type="text"
                    value={newLink.title}
                    onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="资源名称"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">链接 *</label>
                  <input
                    type="url"
                    value={newLink.url}
                    onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="https://..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">描述</label>
                  <input
                    type="text"
                    value={newLink.description}
                    onChange={(e) => setNewLink({ ...newLink, description: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="简短描述"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">分类</label>
                  <select
                    value={newLink.category_id || selectedCategoryId || ''}
                    onChange={(e) => setNewLink({ ...newLink, category_id: e.target.value, subcategory_id: '' })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  >
                    <option value="">请选择分类</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">子分类</label>
                  <select
                    value={newLink.subcategory_id || ''}
                    onChange={(e) => setNewLink({ ...newLink, subcategory_id: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    disabled={!(newLink.category_id || selectedCategoryId)}
                  >
                    <option value="">无</option>
                    {(newLink.category_id || selectedCategoryId) && getCategorySubCategories(newLink.category_id || selectedCategoryId || '').map(sc => (
                      <option key={sc.id} value={sc.id}>{sc.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">网盘类型</label>
                  <select
                    value={newLink.drive_type}
                    onChange={(e) => setNewLink({ ...newLink, drive_type: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  >
                    {driveTypes.map(dt => (
                      <option key={dt.id} value={dt.id}>{dt.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">提取码</label>
                  <input
                    type="text"
                    value={newLink.extract_code}
                    onChange={(e) => setNewLink({ ...newLink, extract_code: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="选填"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">过期时间</label>
                  <select
                    value={newLink.expires_at ? (() => {
                      if (newLink.expires_at === 'permanent') return 'permanent';
                      const now = new Date();
                      const exp = new Date(newLink.expires_at);
                      const months = (exp.getFullYear() - now.getFullYear()) * 12 + (exp.getMonth() - now.getMonth());
                      if (months <= 1) return '1m';
                      if (months <= 3) return '3m';
                      if (months <= 6) return '6m';
                      return '';
                    })() : ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      let expiresAt = '';
                      if (val === 'permanent') {
                        expiresAt = 'permanent';
                      } else if (val) {
                        const months = parseInt(val.replace('m', ''));
                        const d = new Date();
                        d.setMonth(d.getMonth() + months);
                        expiresAt = d.toISOString().split('T')[0];
                      }
                      setNewLink({ ...newLink, expires_at: expiresAt });
                    }}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  >
                    <option value="">不设置</option>
                    <option value="1m">1个月</option>
                    <option value="3m">3个月</option>
                    <option value="6m">6个月</option>
                    <option value="permanent">永久</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">
                    Slug
                    <span className="text-xs text-gray-400 font-normal ml-1">（URL标识符，如：ps-2024 → /s/ps-2024）</span>
                  </label>
                  <input
                    type="text"
                    value={newLink.slug}
                    onChange={(e) => setNewLink({ ...newLink, slug: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="自定义链接标识"
                  />
                </div>
                
                {/* 图标上传 */}
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">软件图标</label>
                  <div className="flex items-center gap-4">
                    {newLinkIcon && (
                      <img src={newLinkIcon} alt="预览" className="w-16 h-16 rounded-lg object-cover border-2 border-gray-200" />
                    )}
                    <div className="flex-1">
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleIconUpload}
                        accept="image/*"
                        className="hidden"
                        id="icon-upload"
                      />
                      <label
                        htmlFor="icon-upload"
                        className="inline-flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50 cursor-pointer text-sm text-gray-600 transition-colors"
                      >
                        <Upload className="w-4 h-4" />
                        {newLinkIcon ? '更换图标' : '上传图标'}
                      </label>
                      {newLinkIcon && (
                        <button
                          onClick={removeIcon}
                          className="ml-2 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          title="移除图标"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">支持 JPG、PNG 格式，大小不超过 2MB</p>
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-4">
                <button onClick={() => { setIsAddingLink(false); setNewLinkIcon(''); if(fileInputRef.current) fileInputRef.current.value = ''; }} className="px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50">取消</button>
                <button onClick={handleAddLink} className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700">添加</button>
              </div>
            </div>
          )}

          {/* 编辑链接表单 */}
          {editingLinkId && (
            <div className="bg-white rounded-2xl border border-indigo-200 p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-4">编辑链接</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">标题 *</label>
                  <input
                    type="text"
                    value={editingLink.title}
                    onChange={(e) => setEditingLink({ ...editingLink, title: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="资源名称"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">链接 *</label>
                  <input
                    type="url"
                    value={editingLink.url}
                    onChange={(e) => setEditingLink({ ...editingLink, url: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="https://..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">描述</label>
                  <input
                    type="text"
                    value={editingLink.description}
                    onChange={(e) => setEditingLink({ ...editingLink, description: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="简短描述"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">分类</label>
                  <select
                    value={editingLink.category_id}
                    onChange={(e) => setEditingLink({ ...editingLink, category_id: e.target.value, subcategory_id: '' })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  >
                    <option value="">请选择分类</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">子分类</label>
                  <select
                    value={editingLink.subcategory_id}
                    onChange={(e) => setEditingLink({ ...editingLink, subcategory_id: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    disabled={!editingLink.category_id}
                  >
                    <option value="">无</option>
                    {editingLink.category_id && subCategories.filter(sc => sc.category_id === editingLink.category_id).map(sc => (
                      <option key={sc.id} value={sc.id}>{sc.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">网盘类型</label>
                  <select
                    value={editingLink.drive_type}
                    onChange={(e) => setEditingLink({ ...editingLink, drive_type: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  >
                    {driveTypes.map(dt => (
                      <option key={dt.id} value={dt.id}>{dt.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">提取码</label>
                  <input
                    type="text"
                    value={editingLink.extract_code}
                    onChange={(e) => setEditingLink({ ...editingLink, extract_code: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="选填"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">过期时间</label>
                  <select
                    value={editingLink.expires_at ? (() => {
                      if (editingLink.expires_at === 'permanent') return 'permanent';
                      const now = new Date();
                      const exp = new Date(editingLink.expires_at);
                      const months = (exp.getFullYear() - now.getFullYear()) * 12 + (exp.getMonth() - now.getMonth());
                      if (months <= 1) return '1m';
                      if (months <= 3) return '3m';
                      if (months <= 6) return '6m';
                      return '';
                    })() : ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      let expiresAt = '';
                      if (val === 'permanent') {
                        expiresAt = 'permanent';
                      } else if (val) {
                        const months = parseInt(val.replace('m', ''));
                        const d = new Date();
                        d.setMonth(d.getMonth() + months);
                        expiresAt = d.toISOString().split('T')[0];
                      }
                      setEditingLink({ ...editingLink, expires_at: expiresAt });
                    }}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  >
                    <option value="">不设置</option>
                    <option value="1m">1个月</option>
                    <option value="3m">3个月</option>
                    <option value="6m">6个月</option>
                    <option value="permanent">永久</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">
                    Slug
                    <span className="text-xs text-gray-400 font-normal ml-1">（URL标识符，如：ps-2024 → /s/ps-2024）</span>
                  </label>
                  <input
                    type="text"
                    value={editingLink.slug}
                    onChange={(e) => setEditingLink({ ...editingLink, slug: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="自定义链接标识"
                  />
                </div>
                
                {/* 编辑图标上传 */}
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">软件图标</label>
                  <div className="flex items-center gap-4">
                    {editingLinkIcon && (
                      <img src={editingLinkIcon} alt="预览" className="w-16 h-16 rounded-lg object-cover border-2 border-gray-200" />
                    )}
                    <div className="flex-1">
                      <input
                        type="file"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (file) {
                            if (!file.type.startsWith('image/')) {
                              alert('请上传图片文件')
                              return
                            }
                            if (file.size > 2 * 1024 * 1024) {
                              alert('图片大小不能超过 2MB')
                              return
                            }
                            const reader = new FileReader()
                            reader.onload = (ev) => {
                              setEditingLinkIcon(ev.target?.result as string)
                            }
                            reader.readAsDataURL(file)
                          }
                        }}
                        accept="image/*"
                        className="hidden"
                        id="edit-icon-upload"
                      />
                      <label
                        htmlFor="edit-icon-upload"
                        className="inline-flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50 cursor-pointer text-sm text-gray-600 transition-colors"
                      >
                        <Upload className="w-4 h-4" />
                        {editingLinkIcon ? '更换图标' : '上传图标'}
                      </label>
                      {editingLinkIcon && (
                        <button
                          onClick={() => setEditingLinkIcon('')}
                          className="ml-2 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          title="移除图标"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">支持 JPG、PNG 格式，大小不超过 2MB</p>
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-4">
                <button onClick={cancelEdit} className="px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50">取消</button>
                <button onClick={handleEdit} className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700">保存修改</button>
              </div>
            </div>
          )}

          {/* 搜索和视图切换 */}
          <div className="bg-white rounded-2xl border border-gray-200 p-4 mb-6">
            <div className="flex items-center gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="搜索链接..."
                  className="w-full pl-10 pr-4 py-2.5 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>
              <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2.5 ${viewMode === 'list' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
                >
                  <List className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2.5 ${viewMode === 'grid' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
                >
                  <Grid className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* 链接列表/网格 */}
          <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
            {/* 列表视图头部 */}
            {viewMode === 'list' && (
              <div className="grid grid-cols-12 gap-4 px-6 py-3 bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-500 items-center">
                <div className="col-span-5">链接信息</div>
                <div className="col-span-2">分类</div>
                <div className="col-span-2">网盘</div>
                <div className="col-span-1">浏览</div>
                <div className="col-span-2">操作</div>
              </div>
            )}

            {filteredLinks.length === 0 ? (
              <div className="py-12 text-center text-gray-400">
                <HardDrive className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>暂无链接</p>
              </div>
            ) : (
              viewMode === 'list' ? (
                /* 列表视图 */
                filteredLinks.map(link => (
                  <div key={link.id} className="grid grid-cols-12 gap-4 px-6 py-4 border-b border-gray-100 hover:bg-gray-50 transition-colors items-center">
                    <div className="col-span-5">
                      <div
                        className="flex items-center gap-3 cursor-pointer"
                        onClick={() => startEdit(link)}
                      >
                        {getLinkDisplayIcon(link)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium text-gray-900 truncate">{link.title}</h3>
                            {link.is_pinned && <Pin className="w-4 h-4 text-amber-500" />}
                            {link.is_featured && <Star className="w-4 h-4 text-amber-500" />}
                          </div>
                          <p className="text-sm text-gray-500 truncate">{link.description || '暂无描述'}</p>
                        </div>
                      </div>
                    </div>
                    <div className="col-span-2">
                      <span className="px-2.5 py-1 bg-gray-100 text-gray-600 text-xs rounded-lg">
                        {categories.find(c => c.id === link.category_id)?.name || '未分类'}
                      </span>
                      {link.subcategory_id && (
                        <span className="ml-1 px-2 py-0.5 bg-indigo-50 text-indigo-600 text-xs rounded">
                          {subCategories.find(sc => sc.id === link.subcategory_id)?.name}
                        </span>
                      )}
                    </div>
                    <div className="col-span-2">
                      <span className="text-sm text-gray-600">
                        {driveTypes.find(d => d.id === link.drive_type)?.name || link.drive_type}
                      </span>
                    </div>
                    <div className="col-span-1">
                      <div className="flex items-center gap-1 text-gray-400 text-sm">
                        <Eye className="w-4 h-4" />
                        {link.click_count?.toLocaleString()}
                      </div>
                    </div>
                    <div className="col-span-2 flex items-center gap-1">
                      <button
                        onClick={(e) => { e.stopPropagation(); copyToClipboard(link.url, link.id); }}
                        className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="复制"
                      >
                        {copiedId === link.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <a
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors inline-flex"
                        title="访问"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                      <button
                        onClick={(e) => { e.stopPropagation(); startEdit(link); }}
                        className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="编辑"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); togglePin(link.id); }}
                        className={`p-2 rounded-lg transition-colors ${link.is_pinned ? 'text-amber-500 bg-amber-50' : 'text-gray-400 hover:text-amber-500 hover:bg-amber-50'}`}
                        title="置顶"
                      >
                        <Pin className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); toggleFeatured(link.id); }}
                        className={`p-2 rounded-lg transition-colors ${link.is_featured ? 'text-amber-500 bg-amber-50' : 'text-gray-400 hover:text-amber-500 hover:bg-amber-50'}`}
                        title="精选"
                      >
                        <Star className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDeleteLink(link.id); }}
                        className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="删除"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                /* 网格视图 */
                <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredLinks.map(link => (
                    <div
                      key={link.id}
                      className="border border-gray-200 rounded-xl p-4 hover:border-indigo-200 hover:shadow-md transition-all cursor-pointer"
                      onClick={() => startEdit(link)}
                    >
                      <div className="flex items-start gap-3 mb-3">
                        {getLinkDisplayIcon(link)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1">
                            <h3 className="font-medium text-gray-900 truncate text-sm">{link.title}</h3>
                            {link.is_pinned && <Pin className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                            {link.is_featured && <Star className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                          </div>
                          <p className="text-xs text-gray-500 truncate mt-0.5">{link.description || '暂无描述'}</p>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1.5 mb-3">
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
                          {categories.find(c => c.id === link.category_id)?.name || '未分类'}
                        </span>
                        {link.subcategory_id && (
                          <span className="px-2 py-0.5 bg-indigo-50 text-indigo-600 text-xs rounded">
                            {subCategories.find(sc => sc.id === link.subcategory_id)?.name}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1 text-xs text-gray-400">
                          <Eye className="w-3.5 h-3.5" />
                          {link.click_count?.toLocaleString()}
                        </div>

                        <div className="flex items-center gap-0.5">
                          <button
                            onClick={(e) => { e.stopPropagation(); copyToClipboard(link.url, link.id); }}
                            className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                            title="复制"
                          >
                            {copiedId === link.id ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); startEdit(link); }}
                            className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                            title="编辑"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); togglePin(link.id); }}
                            className={`p-1.5 rounded transition-colors ${link.is_pinned ? 'text-amber-500 bg-amber-50' : 'text-gray-400 hover:text-amber-500'}`}
                            title="置顶"
                          >
                            <Pin className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleDeleteLink(link.id); }}
                            className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="删除"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
