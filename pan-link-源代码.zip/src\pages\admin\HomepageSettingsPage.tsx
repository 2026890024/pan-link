import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  GripVertical,
  Plus,
  Trash2,
  Save,
  Eye,
  EyeOff,
} from 'lucide-react'
import toast from 'react-hot-toast'

// 模拟首页分类配置
const initialHomepageCategories = [
  { id: '1', name: 'Adobe', icon: 'adobe', is_visible: true, sort_order: 1 },
  { id: '2', name: 'JetBrains', icon: 'code', is_visible: true, sort_order: 2 },
  { id: '3', name: '办公软件', icon: 'briefcase', is_visible: true, sort_order: 3 },
  { id: '4', name: '开发工具', icon: 'terminal', is_visible: true, sort_order: 4 },
  { id: '5', name: '设计资源', icon: 'palette', is_visible: true, sort_order: 5 },
  { id: '6', name: '系统工具', icon: 'settings', is_visible: false, sort_order: 6 },
]

export default function HomepageSettingsPage() {
  const [categories, setCategories] = useState(initialHomepageCategories)
  const [saved, setSaved] = useState(true)

  const toggleVisibility = (id: string) => {
    setCategories(prev => prev.map(cat => 
      cat.id === id ? { ...cat, is_visible: !cat.is_visible } : cat
    ))
    setSaved(false)
  }

  const updateSortOrder = (id: string, direction: 'up' | 'down') => {
    const index = categories.findIndex(c => c.id === id)
    if (index === -1) return
    
    const newIndex = direction === 'up' ? index - 1 : index + 1
    if (newIndex < 0 || newIndex >= categories.length) return

    const newCategories = [...categories]
    ;[newCategories[index], newCategories[newIndex]] = [newCategories[newIndex], newCategories[index]]
    
    // 更新排序号
    newCategories.forEach((cat, idx) => {
      cat.sort_order = idx + 1
    })
    
    setCategories(newCategories)
    setSaved(false)
  }

  const addCategory = () => {
    const newCat = {
      id: `new-${Date.now()}`,
      name: '新分类',
      icon: 'star',
      is_visible: true,
      sort_order: categories.length + 1,
    }
    setCategories(prev => [...prev, newCat])
    setSaved(false)
  }

  const removeCategory = (id: string) => {
    setCategories(prev => prev.filter(c => c.id !== id))
    setSaved(false)
  }

  const updateName = (id: string, name: string) => {
    setCategories(prev => prev.map(c => c.id === id ? { ...c, name } : c))
    setSaved(false)
  }

  const handleSave = () => {
    // 模拟保存
    setTimeout(() => {
      setSaved(true)
      toast.success('首页分类配置已保存')
    }, 500)
  }

  const visibleCount = categories.filter(c => c.is_visible).length

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">首页设置</h1>
          <p className="text-gray-500 mt-1">管理首页显示的分类按钮</p>
        </div>
        <button
          onClick={handleSave}
          className={`px-6 py-2.5 rounded-xl font-medium transition-all duration-200 flex items-center gap-2 ${
            saved
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-200/50'
          }`}
          disabled={saved}
        >
          <Save className="w-5 h-5" />
          {saved ? '已保存' : '保存配置'}
        </button>
      </div>

      {/* 提示信息 */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
        <div className="p-1.5 bg-blue-100 rounded-lg flex-shrink-0">
          <Eye className="w-5 h-5 text-blue-600" />
        </div>
        <div>
          <p className="text-sm text-blue-800 font-medium">配置说明</p>
          <p className="text-sm text-blue-600 mt-1">
            首页将显示 <span className="font-bold">{visibleCount}</span> 个分类按钮（最多建议 6-8 个）。
            拖拽排序可调整首页显示顺序。
          </p>
        </div>
      </div>

      {/* 分类列表 */}
      <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b bg-gray-50/50">
          <h3 className="font-semibold text-gray-900">分类按钮管理</h3>
        </div>
        
        <div className="divide-y">
          {categories
            .sort((a, b) => a.sort_order - b.sort_order)
            .map((cat, index) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`px-6 py-4 flex items-center gap-4 ${
                cat.is_visible ? 'bg-white' : 'bg-gray-50/50'
              }`}
            >
              {/* 拖拽手柄 */}
              <GripVertical className="w-5 h-5 text-gray-300" />

              {/* 显示/隐藏切换 */}
              <button
                onClick={() => toggleVisibility(cat.id)}
                className={`p-2 rounded-lg transition-all duration-200 ${
                  cat.is_visible
                    ? 'bg-green-50 text-green-600 hover:bg-green-100'
                    : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                }`}
                title={cat.is_visible ? '点击隐藏' : '点击显示'}
              >
                {cat.is_visible ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
              </button>

              {/* 排序按钮 */}
              <div className="flex flex-col gap-0.5">
                <button
                  onClick={() => updateSortOrder(cat.id, 'up')}
                  disabled={index === 0}
                  className="p-1 hover:bg-gray-100 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  ↑
                </button>
                <button
                  onClick={() => updateSortOrder(cat.id, 'down')}
                  disabled={index === categories.length - 1}
                  className="p-1 hover:bg-gray-100 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  ↓
                </button>
              </div>

              {/* 分类名称 */}
              <input
                type="text"
                value={cat.name}
                onChange={(e) => updateName(cat.id, e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:border-indigo-300 transition-all text-sm"
              />

              {/* 状态标签 */}
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                cat.is_visible
                  ? 'bg-green-100 text-green-700'
                  : 'bg-gray-100 text-gray-500'
              }`}>
                {cat.is_visible ? '显示中' : '已隐藏'}
              </span>

              {/* 删除按钮 */}
              <button
                onClick={() => removeCategory(cat.id)}
                className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all duration-200"
                title="删除"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </motion.div>
          ))}
        </div>

        {/* 添加分类按钮 */}
        <div className="px-6 py-4 border-t bg-gray-50/30">
          <button
            onClick={addCategory}
            className="w-full py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-indigo-300 hover:text-indigo-600 transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            添加分类
          </button>
        </div>
      </div>

      {/* 预览区域 */}
      <div className="bg-white rounded-xl border shadow-sm p-6">
        <h3 className="font-semibold text-gray-900 mb-4">首页预览</h3>
        <div className="flex items-center gap-3 flex-wrap">
          {categories
            .filter(c => c.is_visible)
            .sort((a, b) => a.sort_order - b.sort_order)
            .map(cat => (
              <span
                key={cat.id}
                className="px-5 py-2 bg-indigo-600 text-white text-sm rounded-full font-medium shadow-md shadow-indigo-200/40"
              >
                {cat.name}
              </span>
            ))}
        </div>
        {visibleCount === 0 && (
          <p className="text-center text-gray-400 py-4">暂无显示的分类</p>
        )}
      </div>
    </div>
  )
}
