import { useState } from 'react'
import {
  Plus,
  Edit2,
  Trash2,
  Star,
  Pin,
  Eye,
  Copy,
  Check,
  ExternalLink,
  Search,
  X,
  Grid,
  List,
} from 'lucide-react'
import { mockLinks, mockCategories, mockSubCategories, driveTypes } from '@/data/mock'

interface Link {
  id: string
  title: string
  url: string
  description: string
  category_id: string
  drive_type: string
  slug: string
  icon: string
  subcategory_id: string
  extract_code: string
  expires_at: string
  click_count: number
  is_pinned: boolean
  is_featured: boolean
  custom_click_count: number
  created_at: string
}

export default function LinksManagementPage() {
  const [links, setLinks] = useState<Link[]>([...mockLinks] as Link[])
  const [searchQuery, setSearchQuery] = useState('')
  const [filterCategory, setFilterCategory] = useState('all')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list')
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [isAdding, setIsAdding] = useState(false)
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10
  
  const [newLink, setNewLink] = useState({
    title: '',
    url: '',
    description: '',
    category_id: mockCategories[0]?.id || '',
    drive_type: 'baidu',
    slug: '',
    icon: '',
    subcategory_id: '',
    extract_code: '',
    expires_at: '',
    custom_click_count: 0,
  })
  
  const [editingLink, setEditingLink] = useState({
    id: '',
    title: '',
    url: '',
    description: '',
    category_id: '',
    drive_type: 'baidu',
    slug: '',
    icon: '',
    subcategory_id: '',
    extract_code: '',
    expires_at: '',
    custom_click_count: 0,
  })

  const filteredLinks = links.filter((link: Link) => {
    const matchesSearch = link.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (link.description && link.description.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesCategory = filterCategory === 'all' || link.category_id === filterCategory
    return matchesSearch && matchesCategory
  })

  const totalPages = Math.ceil(filteredLinks.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedLinks = filteredLinks.slice(startIndex, startIndex + itemsPerPage)

  const copyToClipboard = async (url: string, id: string) => {
    try {
      await navigator.clipboard.writeText(url)
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const togglePin = (id: string) => {
    setLinks(links.map((l: Link) => l.id === id ? { ...l, is_pinned: !l.is_pinned } : l))
  }

  const toggleFeatured = (id: string) => {
    setLinks(links.map((l: Link) => l.id === id ? { ...l, is_featured: !l.is_featured } : l))
  }

  const handleDelete = (id: string) => {
    if (window.confirm('确定删除该链接吗？')) {
      setLinks(links.filter((l: Link) => l.id !== id))
    }
  }

  const toggleSelect = (id: string) => {
    setSelectedIds(selectedIds.includes(id) ? selectedIds.filter((i: string) => i !== id) : [...selectedIds, id])
  }

  const toggleSelectAll = () => {
    if (selectedIds.length === paginatedLinks.length) {
      setSelectedIds([])
    } else {
      setSelectedIds(paginatedLinks.map((l: Link) => l.id))
    }
  }

  const getLinkIcon = (link: Link) => {
    if (link.icon) {
      return (
        <img 
          src={link.icon} 
          alt={link.title}
          className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
        />
      )
    }
    
    const colors: Record<string, string> = {
      baidu: 'bg-gradient-to-br from-blue-500 to-blue-600',
      quark: 'bg-gradient-to-br from-purple-500 to-purple-600',
      aliyun: 'bg-gradient-to-br from-red-500 to-orange-500',
      lanzou: 'bg-gradient-to-br from-orange-500 to-amber-500',
      xunlei: 'bg-gradient-to-br from-cyan-500 to-blue-500',
      custom: 'bg-gradient-to-br from-gray-500 to-gray-600',
    }
    const names: Record<string, string> = {
      baidu: '百度',
      quark: '夸克',
      aliyun: '阿里',
      lanzou: '蓝奏',
      xunlei: '迅雷',
      custom: '?',
    }
    return (
      <div className={`w-10 h-10 rounded-lg ${colors[link.drive_type] || 'bg-gray-500'} flex items-center justify-center text-white font-bold text-xs flex-shrink-0 shadow`}>
        {names[link.drive_type] || '网'}
      </div>
    )
  }

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>, isEditing = false) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        if (isEditing) {
          setEditingLink({ ...editingLink, icon: reader.result as string })
        } else {
          setNewLink({ ...newLink, icon: reader.result as string })
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const handleAdd = () => {
    if (newLink.title.trim() && newLink.url.trim()) {
      const customClickCount = newLink.custom_click_count || 0
      setLinks([{
        id: Date.now().toString(),
        ...newLink,
        slug: newLink.slug || newLink.title.slice(0, 10).replace(/\s/g, '-').toLowerCase(),
        click_count: customClickCount,
        created_at: new Date().toISOString(),
        is_pinned: false,
        is_featured: false,
        custom_click_count: customClickCount,
      } as Link, ...links])
      setNewLink({ 
        title: '', url: '', description: '', 
        category_id: mockCategories[0]?.id || '', 
        drive_type: 'baidu', slug: '', icon: '', 
        subcategory_id: '', extract_code: '', 
        expires_at: '', custom_click_count: 0 
      })
      setIsAdding(false)
    }
  }

  const startEdit = (link: Link) => {
    setEditingLinkId(link.id)
    setEditingLink({
      id: link.id,
      title: link.title,
      url: link.url,
      description: link.description || '',
      category_id: link.category_id,
      drive_type: link.drive_type,
      slug: link.slug,
      icon: link.icon || '',
      subcategory_id: link.subcategory_id || '',
      extract_code: link.extract_code || '',
      expires_at: link.expires_at || '',
      custom_click_count: link.custom_click_count || 0,
    })
    setIsAdding(false)
  }

  const handleEdit = () => {
    if (editingLink.id && editingLink.title.trim() && editingLink.url.trim()) {
      setLinks(links.map((l: Link) => {
        if (l.id === editingLink.id) {
          const oldCustomCount = l.custom_click_count || 0
          const newCustomCount = editingLink.custom_click_count || 0
          const diff = newCustomCount - oldCustomCount
          return {
            ...l,
            ...editingLink,
            click_count: (l.click_count || 0) + diff,
            custom_click_count: newCustomCount,
          }
        }
        return l
      }))
      setEditingLinkId(null)
      setEditingLink({ 
        id: '', title: '', url: '', description: '', 
        category_id: '', drive_type: 'baidu', slug: '', icon: '', 
        subcategory_id: '', extract_code: '', 
        expires_at: '', custom_click_count: 0 
      })
    }
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">链接管理</h1>
          <p className="text-gray-500 mt-1">共 {links.length} 个链接</p>
        </div>
        <button
          type="button"
          onClick={() => {
            setIsAdding(true)
            setEditingLinkId(null)
          }}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-medium"
        >
          <Plus className="w-5 h-5" />
          添加链接
        </button>
      </div>

      {/* Add/Edit Form */}
      {(isAdding || editingLinkId) && (
        <div className="bg-white rounded-2xl border border-gray-200 p-6 mb-6">
          <h3 className="font-semibold text-gray-900 mb-4">
            {editingLinkId ? '编辑链接' : '添加新链接'}
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">标题</label>
              <input
                type="text"
                value={editingLinkId ? editingLink.title : newLink.title}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, title: e.target.value })
                  : setNewLink({ ...newLink, title: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="资源名称"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">链接</label>
              <input
                type="url"
                value={editingLinkId ? editingLink.url : newLink.url}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, url: e.target.value })
                  : setNewLink({ ...newLink, url: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="https://..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">描述</label>
              <input
                type="text"
                value={editingLinkId ? editingLink.description : newLink.description}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, description: e.target.value })
                  : setNewLink({ ...newLink, description: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="简短描述"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">分类</label>
              <select
                value={editingLinkId ? editingLink.category_id : newLink.category_id}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, category_id: e.target.value, subcategory_id: '' })
                  : setNewLink({ ...newLink, category_id: e.target.value, subcategory_id: '' })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                {mockCategories.map((cat: any) => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">子分类</label>
              <select
                value={editingLinkId ? editingLink.subcategory_id : newLink.subcategory_id}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, subcategory_id: e.target.value })
                  : setNewLink({ ...newLink, subcategory_id: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                <option value="">无</option>
                {mockSubCategories
                  .filter((sc: any) => sc.category_id === (editingLinkId ? editingLink.category_id : newLink.category_id))
                  .map((sc: any) => (
                    <option key={sc.id} value={sc.id}>{sc.name}</option>
                  ))
                }
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">网盘类型</label>
              <select
                value={editingLinkId ? editingLink.drive_type : newLink.drive_type}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, drive_type: e.target.value })
                  : setNewLink({ ...newLink, drive_type: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                {driveTypes.map((dt: any) => (
                  <option key={dt.id} value={dt.id}>{dt.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">提取码</label>
              <input
                type="text"
                value={editingLinkId ? editingLink.extract_code : newLink.extract_code}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, extract_code: e.target.value })
                  : setNewLink({ ...newLink, extract_code: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="选填"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">过期时间</label>
              <input
                type="date"
                value={editingLinkId ? editingLink.expires_at : newLink.expires_at}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, expires_at: e.target.value })
                  : setNewLink({ ...newLink, expires_at: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Slug</label>
              <input
                type="text"
                value={editingLinkId ? editingLink.slug : newLink.slug}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, slug: e.target.value })
                  : setNewLink({ ...newLink, slug: e.target.value })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="自定义链接标识"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">自定义浏览量</label>
              <input
                type="number"
                value={editingLinkId ? editingLink.custom_click_count : newLink.custom_click_count}
                onChange={(e) => editingLinkId 
                  ? setEditingLink({ ...editingLink, custom_click_count: parseInt(e.target.value) || 0 })
                  : setNewLink({ ...newLink, custom_click_count: parseInt(e.target.value) || 0 })
                }
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="自定义浏览量（会累加到实际浏览量上）"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">自定义图标</label>
              <div className="flex items-center gap-4">
                {(editingLinkId ? editingLink.icon : newLink.icon) && (
                  <img src={(editingLinkId ? editingLink.icon : newLink.icon) as string} alt="预览" className="w-10 h-10 rounded-lg object-cover" />
                )}
                <label className="flex-1">
                  <div className="w-full px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors cursor-pointer text-center text-gray-500">
                    {(editingLinkId ? editingLink.icon : newLink.icon) ? '更换图标' : '上传图标'}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleIconUpload(e, !!editingLinkId)}
                    className="hidden"
                  />
                </label>
                {(editingLinkId ? editingLink.icon : newLink.icon) && (
                  <button
                    type="button"
                    onClick={() => editingLinkId 
                      ? setEditingLink({ ...editingLink, icon: '' })
                      : setNewLink({ ...newLink, icon: '' })
                    }
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-3 mt-4">
            <button 
              type="button"
              onClick={() => {
                setIsAdding(false)
                setEditingLinkId(null)
                setNewLink({ 
                  title: '', url: '', description: '', 
                  category_id: mockCategories[0]?.id || '', 
                  drive_type: 'baidu', slug: '', icon: '', 
                  subcategory_id: '', extract_code: '', 
                  expires_at: '', custom_click_count: 0 
                })
                setEditingLink({ 
                  id: '', title: '', url: '', description: '', 
                  category_id: '', drive_type: 'baidu', slug: '', icon: '', 
                  subcategory_id: '', extract_code: '', 
                  expires_at: '', custom_click_count: 0 
                })
              }} 
              className="px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50"
            >
              取消
            </button>
            <button 
              type="button"
              onClick={editingLinkId ? handleEdit : handleAdd} 
              className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700"
            >
              {editingLinkId ? '保存修改' : '添加'}
            </button>
          </div>
        </div>
      )}

      {/* Toolbar */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4 mb-6">
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索链接..."
              className="w-full pl-10 pr-4 py-2.5 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
            />
          </div>

          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-4 py-2.5 bg-gray-100 rounded-xl border-0 focus:outline-none"
          >
            <option value="all">全部分类</option>
            {mockCategories.map((cat: any) => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>

          <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`p-2.5 border-r border-gray-200 ${viewMode === 'list' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
            >
              <List className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`p-2.5 ${viewMode === 'grid' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
            >
              <Grid className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Links List/Grid View */}
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        {viewMode === 'list' ? (
          <>
            {/* List Header */}
            <div className="grid grid-cols-12 gap-4 px-6 py-3 bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-500 items-center">
              <div className="col-span-1">
                <input
                  type="checkbox"
                  checked={selectedIds.length === paginatedLinks.length && paginatedLinks.length > 0}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 rounded border-gray-300"
                />
              </div>
              <div className="col-span-4">链接信息</div>
              <div className="col-span-2">分类/子分类</div>
              <div className="col-span-2">数据</div>
              <div className="col-span-3">操作</div>
            </div>

            {/* List Items */}
            {paginatedLinks.map((link: Link) => (
              <div key={link.id} className="grid grid-cols-12 gap-4 px-6 py-4 border-b border-gray-100 hover:bg-gray-50 transition-colors items-center">
                <div className="col-span-1">
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(link.id)}
                    onChange={() => toggleSelect(link.id)}
                    className="w-4 h-4 rounded border-gray-300"
                  />
                </div>
                <div className="col-span-4">
                  <div 
                    className="flex items-center gap-3 cursor-pointer"
                    onClick={() => startEdit(link)}
                  >
                    {getLinkIcon(link)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-gray-900 truncate">{link.title}</h3>
                        {link.is_pinned && <Pin className="w-4 h-4 text-amber-500 flex-shrink-0" />}
                        {link.is_featured && <Star className="w-4 h-4 text-amber-500 flex-shrink-0" />}
                      </div>
                      <p className="text-sm text-gray-500 truncate">{link.description}</p>
                      {link.extract_code && (
                        <p className="text-xs text-gray-400 mt-0.5">提取码: {link.extract_code}</p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-span-2">
                  <div className="space-y-1">
                    <span className="px-2.5 py-1 bg-gray-100 text-gray-600 text-xs rounded-lg block w-fit">
                      {mockCategories.find((c: any) => c.id === link.category_id)?.name}
                    </span>
                    {link.subcategory_id && (
                      <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-600 text-xs rounded-lg block w-fit">
                        {mockSubCategories.find((sc: any) => sc.id === link.subcategory_id)?.name}
                      </span>
                    )}
                  </div>
                </div>
                <div className="col-span-2">
                  <div className="flex flex-col gap-1 text-gray-400 text-sm">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {link.click_count?.toLocaleString()}
                      {link.custom_click_count > 0 && (
                        <span className="text-xs text-indigo-500">(自定义:{link.custom_click_count})</span>
                      )}
                    </div>
                    {link.expires_at && (
                      <div className="text-xs text-gray-400">
                        过期: {new Date(link.expires_at).toLocaleDateString()}
                      </div>
                    )}
                  </div>
                </div>
                <div className="col-span-3 flex items-center gap-1">
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); copyToClipboard(link.url, link.id); }}
                    className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                    title="复制"
                  >
                    {copiedId === link.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors inline-flex"
                    title="访问"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); startEdit(link); }}
                    className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                    title="编辑"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); togglePin(link.id); }}
                    className={`p-2 rounded-lg transition-colors ${link.is_pinned ? 'text-amber-500 bg-amber-50' : 'text-gray-400 hover:text-amber-500 hover:bg-amber-50'}`}
                    title="置顶"
                  >
                    <Pin className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); toggleFeatured(link.id); }}
                    className={`p-2 rounded-lg transition-colors ${link.is_featured ? 'text-amber-500 bg-amber-50' : 'text-gray-400 hover:text-amber-500 hover:bg-amber-50'}`}
                    title="精选"
                  >
                    <Star className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); handleDelete(link.id); }}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="删除"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </>
        ) : (
          /* Grid View */
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {paginatedLinks.map((link: Link) => (
              <div 
                key={link.id} 
                className="border border-gray-200 rounded-xl p-4 hover:border-indigo-200 hover:shadow-md transition-all cursor-pointer"
                onClick={() => startEdit(link)}
              >
                <div className="flex items-start gap-3 mb-3">
                  {getLinkIcon(link)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <h3 className="font-medium text-gray-900 truncate text-sm">{link.title}</h3>
                      {link.is_pinned && <Pin className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                      {link.is_featured && <Star className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                    </div>
                    <p className="text-xs text-gray-500 truncate mt-0.5">{link.description}</p>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-1.5 mb-3">
                  <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
                    {mockCategories.find((c: any) => c.id === link.category_id)?.name}
                  </span>
                  {link.subcategory_id && (
                    <span className="px-2 py-0.5 bg-indigo-50 text-indigo-600 text-xs rounded">
                      {mockSubCategories.find((sc: any) => sc.id === link.subcategory_id)?.name}
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-xs text-gray-400">
                    <Eye className="w-3.5 h-3.5" />
                    {link.click_count?.toLocaleString()}
                  </div>
                  
                  <div className="flex items-center gap-0.5">
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); copyToClipboard(link.url, link.id); }}
                      className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                      title="复制"
                    >
                      {copiedId === link.id ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); togglePin(link.id); }}
                      className={`p-1.5 rounded transition-colors ${link.is_pinned ? 'text-amber-500 bg-amber-50' : 'text-gray-400 hover:text-amber-500'}`}
                      title="置顶"
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); handleDelete(link.id); }}
                      className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                      title="删除"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 p-4 border-t border-gray-200">
            <button
              type="button"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1.5 rounded-lg text-sm border border-gray-200 hover:border-indigo-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              上一页
            </button>
            
            {Array.from({ length: totalPages }, (_, i) => i + 1)
              .filter((page: number) => 
                page === 1 || 
                page === totalPages || 
                Math.abs(page - currentPage) <= 2
              )
              .map((page: number, index: number, array: number[]) => (
                <span key={page}>
                  {index > 0 && array[index - 1] !== page - 1 && (
                    <span className="px-2 text-gray-400">...</span>
                  )}
                  <button
                    type="button"
                    onClick={() => setCurrentPage(page)}
                    className={`w-9 h-9 rounded-lg text-sm transition-all ${
                      currentPage === page
                        ? 'bg-indigo-600 text-white font-medium shadow-md'
                        : 'border border-gray-200 hover:border-indigo-200'
                    }`}
                  >
                    {page}
                  </button>
                </span>
              ))
            }
            
            <button
              type="button"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1.5 rounded-lg text-sm border border-gray-200 hover:border-indigo-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              下一页
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
