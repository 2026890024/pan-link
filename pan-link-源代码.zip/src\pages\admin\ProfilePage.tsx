import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  User,
  Lock,
  Tag,
  FolderOpen,
  Plus,
  Pencil,
  Trash2,
  Check,
  X,
  Upload,
  Palette,
  Save,
} from 'lucide-react'
import { mockCategories, mockTags } from '@/data/mock'
import toast from 'react-hot-toast'

type Tab = 'profile' | 'categories' | 'tags' | 'password'

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState<Tab>('profile')
  const [username, setUsername] = useState('Admin User')
  const [avatar, setAvatar] = useState<string | null>(null)
  const [isEditingCategory, setIsEditingCategory] = useState<string | null>(null)
  const [isEditingTag, setIsEditingTag] = useState<string | null>(null)
  const [newCategoryName, setNewCategoryName] = useState('')
  const [newTagName, setNewTagName] = useState('')
  const [newTagColor, setNewTagColor] = useState('#6366F1')
  const [showAddCategory, setShowAddCategory] = useState(false)
  const [showAddTag, setShowAddTag] = useState(false)

  const [categories, setCategories] = useState(mockCategories)
  const [tags, setTags] = useState(mockTags)

  // 头像上传处理
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setAvatar(reader.result as string)
        toast.success('头像已更新')
      }
      reader.readAsDataURL(file)
    }
  }

  const tabs = [
    { id: 'profile' as Tab, label: '账号信息', icon: User },
    { id: 'categories' as Tab, label: '分类管理', icon: FolderOpen },
    { id: 'tags' as Tab, label: '标签管理', icon: Tag },
    { id: 'password' as Tab, label: '修改密码', icon: Lock },
  ]

  const colorOptions = [
    '#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899', '#6366F1', '#14B8A6'
  ]

  const handleSaveProfile = () => {
    toast.success('个人资料已保存')
  }

  const handleSavePassword = () => {
    toast.success('密码已修改')
  }

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) {
      toast.error('请输入分类名称')
      return
    }
    const newCategory = {
      id: Date.now().toString(),
      user_id: '1',
      name: newCategoryName,
      logo_url: null,
      sort_order: categories.length + 1,
      is_system: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setCategories([...categories, newCategory])
    setNewCategoryName('')
    setShowAddCategory(false)
    toast.success('分类已添加')
  }

  const handleDeleteCategory = (id: string) => {
    setCategories(categories.filter((c) => c.id !== id))
    toast.success('分类已删除')
  }

  const handleAddTag = () => {
    if (!newTagName.trim()) {
      toast.error('请输入标签名称')
      return
    }
    const newTag = {
      id: Date.now().toString(),
      user_id: '1',
      name: newTagName,
      color: newTagColor,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setTags([...tags, newTag])
    setNewTagName('')
    setNewTagColor('#6366F1')
    setShowAddTag(false)
    toast.success('标签已添加')
  }

  const handleDeleteTag = (id: string) => {
    setTags(tags.filter((t) => t.id !== id))
    toast.success('标签已删除')
  }

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">个人中心</h1>
        <p className="text-gray-500 mt-1">管理您的账号信息和偏好设置</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* 侧边栏 */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:w-64 flex-shrink-0"
        >
          <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
            {/* 用户信息卡片 */}
            <div className="p-6 text-center border-b">
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-2xl font-bold mb-3">
                {username.charAt(0).toUpperCase()}
              </div>
              <h3 className="font-semibold text-gray-800">{username}</h3>
              <p className="text-sm text-gray-500 mt-1">admin@example.com</p>
            </div>

            {/* 导航 */}
            <nav className="p-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </motion.div>

        {/* 内容区 */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex-1"
        >
          {/* 账号信息 */}
          {activeTab === 'profile' && (
            <div className="bg-white rounded-xl border shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">账号信息</h2>
              <div className="space-y-6">
                {/* 头像 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    头像
                  </label>
                  <div className="flex items-center gap-4">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-2xl font-bold overflow-hidden">
                      {avatar ? (
                        <img src={avatar} alt="头像" className="w-full h-full object-cover" />
                      ) : (
                        username.charAt(0).toUpperCase()
                      )}
                    </div>
                    <label className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2 cursor-pointer">
                      <Upload className="w-4 h-4" />
                      上传新头像
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                {/* 用户名 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    用户名
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* 邮箱 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    邮箱
                  </label>
                  <input
                    type="email"
                    value="admin@example.com"
                    readOnly
                    className="w-full px-4 py-2 border rounded-lg bg-gray-50"
                  />
                </div>

                <button
                  onClick={handleSaveProfile}
                  className="px-6 py-2 gradient-primary text-white rounded-lg font-medium hover:shadow-lg transition-shadow flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  保存修改
                </button>
              </div>
            </div>
          )}

          {/* 分类管理 */}
          {activeTab === 'categories' && (
            <div className="bg-white rounded-xl border shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">分类管理</h2>
                <button
                  onClick={() => setShowAddCategory(true)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  添加分类
                </button>
              </div>

              {/* 添加分类表单 */}
              {showAddCategory && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <input
                      type="text"
                      value={newCategoryName}
                      onChange={(e) => setNewCategoryName(e.target.value)}
                      placeholder="分类名称"
                      className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      onClick={handleAddCategory}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      保存
                    </button>
                    <button
                      onClick={() => setShowAddCategory(false)}
                      className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                    >
                      取消
                    </button>
                  </div>
                </div>
              )}

              {/* 分类列表 */}
              <div className="space-y-3">
                {categories.map((category) => (
                  <div
                    key={category.id}
                    className="flex items-center gap-4 p-4 rounded-lg border hover:bg-gray-50 transition-colors"
                  >
                    <div className="w-12 h-12 rounded-xl bg-gray-50 flex items-center justify-center">
                      {category.logo_url ? (
                        <img
                          src={category.logo_url}
                          alt=""
                          className="w-8 h-8 object-contain"
                        />
                      ) : (
                        <FolderOpen className="w-6 h-6 text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">{category.name}</p>
                      <p className="text-sm text-gray-500">
                        {category.is_system ? '系统分类' : '自定义分类'}
                      </p>
                    </div>
                    {!category.is_system && (
                      <div className="flex items-center gap-2">
                        <button className="p-2 hover:bg-gray-100 rounded-lg">
                          <Pencil className="w-4 h-4 text-gray-500" />
                        </button>
                        <button
                          onClick={() => handleDeleteCategory(category.id)}
                          className="p-2 hover:bg-red-50 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 标签管理 */}
          {activeTab === 'tags' && (
            <div className="bg-white rounded-xl border shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">标签管理</h2>
                <button
                  onClick={() => setShowAddTag(true)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  添加标签
                </button>
              </div>

              {/* 添加标签表单 */}
              {showAddTag && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <div className="space-y-4">
                    <input
                      type="text"
                      value={newTagName}
                      onChange={(e) => setNewTagName(e.target.value)}
                      placeholder="标签名称"
                      className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        标签颜色
                      </label>
                      <div className="flex items-center gap-2">
                        {colorOptions.map((color) => (
                          <button
                            key={color}
                            onClick={() => setNewTagColor(color)}
                            className={`w-8 h-8 rounded-full border-2 ${
                              newTagColor === color ? 'border-gray-800' : 'border-transparent'
                            }`}
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={handleAddTag}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        保存
                      </button>
                      <button
                        onClick={() => setShowAddTag(false)}
                        className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                      >
                        取消
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 标签列表 */}
              <div className="flex flex-wrap gap-3">
                {tags.map((tag) => (
                  <div
                    key={tag.id}
                    className="flex items-center gap-2 px-4 py-2 rounded-full"
                    style={{ backgroundColor: `${tag.color}20` }}
                  >
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: tag.color }}
                    />
                    <span style={{ color: tag.color }}>{tag.name}</span>
                    <button
                      onClick={() => handleDeleteTag(tag.id)}
                      className="ml-1 hover:bg-white/50 rounded-full p-0.5"
                    >
                      <X className="w-3 h-3" style={{ color: tag.color }} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 修改密码 */}
          {activeTab === 'password' && (
            <div className="bg-white rounded-xl border shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">修改密码</h2>
              <div className="space-y-6 max-w-md">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    当前密码
                  </label>
                  <input
                    type="password"
                    placeholder="请输入当前密码"
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    新密码
                  </label>
                  <input
                    type="password"
                    placeholder="请输入新密码"
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    确认新密码
                  </label>
                  <input
                    type="password"
                    placeholder="请再次输入新密码"
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <button
                  onClick={handleSavePassword}
                  className="px-6 py-2 gradient-primary text-white rounded-lg font-medium hover:shadow-lg transition-shadow flex items-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  修改密码
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}
