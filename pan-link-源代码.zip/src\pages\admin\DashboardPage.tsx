import { motion } from 'framer-motion'
import {
  Link2,
  Eye,
  Clock,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Pin,
  ArrowUpRight,
} from 'lucide-react'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'
import { mockLinks, mockCategories, mockSubCategories } from '@/data/mock'

// 获取链接图标
function getLinkIcon(link: typeof mockLinks[0]) {
  if (link.icon) {
    return (
      <img 
        src={link.icon} 
        alt={link.title}
        className="w-8 h-8 rounded-lg object-cover flex-shrink-0"
      />
    )
  }
  
  const colors: Record<string, string> = {
    baidu: 'bg-gradient-to-br from-blue-500 to-blue-600',
    quark: 'bg-gradient-to-br from-purple-500 to-purple-600',
    aliyun: 'bg-gradient-to-br from-red-500 to-orange-500',
    lanzou: 'bg-gradient-to-br from-orange-500 to-amber-500',
    xunlei: 'bg-gradient-to-br from-cyan-500 to-blue-500',
  }
  const names: Record<string, string> = {
    baidu: '百度',
    quark: '夸克',
    aliyun: '阿里',
    lanzou: '蓝奏',
    xunlei: '迅雷',
  }
  return (
    <div className={`w-8 h-8 rounded-lg ${colors[link.drive_type] || 'bg-gray-500'} flex items-center justify-center text-white font-bold text-xs flex-shrink-0`}>
      {names[link.drive_type] || '网'}
    </div>
  )
}

// KPI 卡片数据
const kpiCards = [
  {
    title: '总链接数',
    value: mockLinks.length,
    change: '+12%',
    trend: 'up',
    icon: Link2,
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    title: '总点击量',
    value: mockLinks.reduce((sum, link) => sum + (link.click_count || 0), 0),
    change: '+23%',
    trend: 'up',
    icon: Eye,
    bgColor: 'bg-purple-50',
    iconColor: 'text-purple-600',
  },
  {
    title: '即将过期',
    value: mockLinks.filter(l => l.expires_at && new Date(l.expires_at) < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)).length,
    change: '-2',
    trend: 'down',
    icon: Clock,
    bgColor: 'bg-amber-50',
    iconColor: 'text-amber-600',
  },
]

// 近7天访问趋势
const weekTrend = [
  { date: '周一', clicks: 1200 },
  { date: '周二', clicks: 1890 },
  { date: '周三', clicks: 2100 },
  { date: '周四', clicks: 1750 },
  { date: '周五', clicks: 2300 },
  { date: '周六', clicks: 2800 },
  { date: '周日', clicks: 3200 },
]

// 分类分布
const categoryDistribution = mockCategories.map((cat) => ({
  name: cat.name.replace('网盘', ''),
  value: mockLinks.filter((l) => l.category_id === cat.id).length,
  color: ['#3B82F6', '#8B5CF6', '#EC4899', '#F59E0B'][mockCategories.indexOf(cat) % 4],
}))

// 有效期分布
const validityDistribution = [
  { period: '1个月内', count: 12 },
  { period: '3个月', count: 25 },
  { period: '6个月', count: 38 },
  { period: '1年', count: 35 },
  { period: '永久', count: 18 },
]

// Top 10 热门链接
const topLinks = [...mockLinks]
  .sort((a, b) => b.click_count - a.click_count)
  .slice(0, 5)

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">数据仪表盘</h1>
        <p className="text-gray-500 mt-1">实时监控链接数据和分析指标</p>
      </div>

      {/* KPI 卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-6 border shadow-sm"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500">{card.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {card.value.toLocaleString()}
                </p>
                <div className="flex items-center gap-1 mt-2">
                  {card.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-500" />
                  )}
                  <span
                    className={`text-sm ${
                      card.trend === 'up' ? 'text-green-500' : 'text-red-500'
                    }`}
                  >
                    {card.change}
                  </span>
                  <span className="text-gray-400 text-sm">较上周</span>
                </div>
              </div>
              <div className={`w-12 h-12 rounded-xl ${card.bgColor} flex items-center justify-center`}>
                <card.icon className={`w-6 h-6 ${card.iconColor}`} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* 图表区域 */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* 近7天访问趋势 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl p-6 border shadow-sm"
        >
          <h3 className="text-lg font-semibold text-gray-900 mb-4">近7天访问趋势</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weekTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" stroke="#9ca3af" fontSize={12} />
                <YAxis stroke="#9ca3af" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="clicks"
                  stroke="#3B82F6"
                  strokeWidth={2}
                  dot={{ fill: '#3B82F6', r: 4 }}
                  name="点击量"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* 分类分布 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl p-6 border shadow-sm"
        >
          <h3 className="text-lg font-semibold text-gray-900 mb-4">分类分布</h3>
          <div className="h-64 flex items-center">
            <ResponsiveContainer width="60%" height="100%">
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {categoryDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-3">
              {categoryDistribution.map((item, index) => (
                <div key={item.name} className="flex items-center gap-3">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-sm text-gray-600 flex-1">{item.name}</span>
                  <span className="text-sm font-medium text-gray-900">
                    {item.value} 个
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* 有效期分布 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-xl p-6 border shadow-sm"
        >
          <h3 className="text-lg font-semibold text-gray-900 mb-4">有效期分布</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={validityDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="period" stroke="#9ca3af" fontSize={12} />
                <YAxis stroke="#9ca3af" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="count" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* 热门链接排行 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-xl p-6 border shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">热门链接 Top 5</h3>
            <a
              href="/admin/links"
              className="text-sm text-blue-600 hover:underline flex items-center gap-1"
            >
              查看全部
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
          <div className="space-y-3">
            {topLinks.map((link, index) => (
              <a
                key={link.id}
                href={`/s/${link.slug}`}
                className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors group"
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm ${
                    index === 0
                      ? 'bg-amber-500'
                      : index === 1
                      ? 'bg-gray-400'
                      : index === 2
                      ? 'bg-amber-700'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {index + 1}
                </div>
                {getLinkIcon(link)}
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-800 truncate group-hover:text-blue-600 transition-colors">
                    {link.title}
                  </p>
                  <p className="text-sm text-gray-500">{link.category_name}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 text-gray-600">
                    <Eye className="w-4 h-4" />
                    <span className="font-medium">{link.click_count?.toLocaleString()}</span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </motion.div>
      </div>

      {/* 快捷操作 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-white rounded-xl p-6 border shadow-sm"
      >
        <h3 className="text-lg font-semibold text-gray-900 mb-4">快捷操作</h3>
        <div className="grid md:grid-cols-4 gap-4">
          <a
            href="/admin/links"
            className="flex items-center gap-3 p-4 rounded-xl border hover:border-blue-200 hover:bg-blue-50 transition-all"
          >
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <Link2 className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="font-medium text-gray-800">添加链接</p>
              <p className="text-xs text-gray-500">创建新分享</p>
            </div>
          </a>
          <a
            href="/admin/data"
            className="flex items-center gap-3 p-4 rounded-xl border hover:border-green-200 hover:bg-green-50 transition-all"
          >
            <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="font-medium text-gray-800">导出数据</p>
              <p className="text-xs text-gray-500">CSV/Excel</p>
            </div>
          </a>
          <a
            href="/admin/profile"
            className="flex items-center gap-3 p-4 rounded-xl border hover:border-purple-200 hover:bg-purple-50 transition-all"
          >
            <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
              <Pin className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="font-medium text-gray-800">管理分类</p>
              <p className="text-xs text-gray-500">自定义分类</p>
            </div>
          </a>
          <div className="flex items-center gap-3 p-4 rounded-xl border hover:border-amber-200 hover:bg-amber-50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="font-medium text-gray-800">过期提醒</p>
              <p className="text-xs text-gray-500">
                {mockLinks[0]?.expires_at 
                  ? Math.ceil((new Date(mockLinks[0].expires_at).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) + ' 天'
                  : '无过期'
                }
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
