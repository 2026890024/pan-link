import { useState, useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search as SearchIcon,
  Eye,
  Clock,
  Pin,
  History,
  X,
  TrendingUp,
  FolderOpen,
} from 'lucide-react'
import { mockLinks, mockCategories, mockSubCategories } from '@/data/mock'

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [query, setQuery] = useState(searchParams.get('q') || '')
  const [results, setResults] = useState(mockLinks)
  const [recentSearches, setRecentSearches] = useState<string[]>([])
  const [isSearching, setIsSearching] = useState(false)

  // 加载搜索历史
  useEffect(() => {
    const history = localStorage.getItem('recentSearches')
    if (history) {
      setRecentSearches(JSON.parse(history))
    }
  }, [])

  // 获取子分类名称
  const getSubCategoryName = (subcategoryId: string) => {
    if (!subcategoryId) return ''
    const sub = mockSubCategories.find(sc => sc.id === subcategoryId)
    return sub ? sub.name : ''
  }

  // 执行搜索
  useEffect(() => {
    if (!query.trim()) {
      setResults(mockLinks)
      return
    }

    setIsSearching(true)
    
    // 模拟搜索延迟
    const timer = setTimeout(() => {
      const filtered = mockLinks.filter((link) => {
        const searchLower = query.toLowerCase()
        const subCategoryName = getSubCategoryName(link.subcategory_id || '').toLowerCase()
        return (
          link.name.toLowerCase().includes(searchLower) ||
          link.title.toLowerCase().includes(searchLower) ||
          link.description.toLowerCase().includes(searchLower) ||
          (link.category_id && mockCategories.find(c => c.id === link.category_id)?.name.toLowerCase().includes(searchLower)) ||
          subCategoryName.includes(searchLower)
        )
      })
      setResults(filtered)
      setIsSearching(false)
    }, 300)

    return () => clearTimeout(timer)
  }, [query])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      // 保存搜索历史
      const newHistory = [query, ...recentSearches.filter((s) => s !== query)].slice(0, 10)
      setRecentSearches(newHistory)
      localStorage.setItem('recentSearches', JSON.stringify(newHistory))
      setSearchParams({ q: query })
    }
  }

  const handleClearHistory = () => {
    setRecentSearches([])
    localStorage.removeItem('recentSearches')
  }

  const handleRecentSearch = (term: string) => {
    setQuery(term)
  }

  // 热门搜索
  const hotSearches = ['Adobe', 'Photoshop', 'Office', 'IDEA', '设计']

  // 获取链接图标
  const getLinkIcon = (link: typeof mockLinks[0]) => {
    if (link.icon) {
      return (
        <img 
          src={link.icon} 
          alt={link.name}
          className="w-12 h-12 rounded-xl object-cover flex-shrink-0"
        />
      )
    }
    
    // 显示分类 logo
    const category = mockCategories.find(c => c.id === link.category_id)
    if (category?.icon) {
      return (
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center flex-shrink-0">
          <FolderOpen className="w-6 h-6 text-gray-400" />
        </div>
      )
    }
    
    return (
      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center flex-shrink-0">
        <FolderOpen className="w-6 h-6 text-gray-400" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      {/* 搜索框 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <form onSubmit={handleSearch} className="relative">
          <SearchIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索资源名称、分类、标签..."
            className="w-full pl-14 pr-14 py-5 bg-white border-2 border-gray-100 rounded-2xl text-lg focus:outline-none focus:border-indigo-500 transition-colors shadow-sm"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="absolute right-20 top-1/2 -translate-y-1/2 p-2 rounded-full hover:bg-gray-100"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          )}
          <button
            type="submit"
            className="absolute right-4 top-1/2 -translate-y-1/2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors"
          >
            搜索
          </button>
        </form>
      </motion.div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* 侧边栏 */}
        <motion.aside
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:w-64 flex-shrink-0"
        >
          {/* 搜索历史 */}
          {recentSearches.length > 0 && (
            <div className="bg-white rounded-2xl p-5 shadow-sm border mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                  <History className="w-5 h-5 text-gray-400" />
                  搜索历史
                </h3>
                <button
                  onClick={handleClearHistory}
                  className="text-sm text-gray-400 hover:text-gray-600"
                >
                  清空
                </button>
              </div>
              <div className="space-y-2">
                {recentSearches.map((term, index) => (
                  <button
                    key={index}
                    onClick={() => handleRecentSearch(term)}
                    className="block w-full text-left px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors text-sm"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 热门搜索 */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              热门搜索
            </h3>
            <div className="flex flex-wrap gap-2">
              {hotSearches.map((term, index) => (
                <button
                  key={index}
                  onClick={() => handleRecentSearch(term)}
                  className="px-3 py-1.5 bg-gray-50 hover:bg-indigo-50 text-gray-600 hover:text-indigo-600 rounded-full text-sm transition-colors"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        </motion.aside>

        {/* 搜索结果 */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="flex-1"
        >
          {/* 结果统计 */}
          {!isSearching && (
            <div className="mb-6 text-gray-500">
              {query ? (
                <span>
                  找到 <strong>{results.length}</strong> 个与「{query}」相关的结果
                </span>
              ) : (
                <span>共 <strong>{results.length}</strong> 个资源</span>
              )}
            </div>
          )}

          {/* 结果列表 */}
          <AnimatePresence mode="wait">
            {isSearching ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-3"
              >
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-white rounded-xl border p-4 animate-pulse">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gray-200 rounded-xl" />
                      <div className="flex-1">
                        <div className="h-5 bg-gray-200 rounded w-3/4 mb-2" />
                        <div className="h-4 bg-gray-100 rounded w-1/2" />
                      </div>
                    </div>
                  </div>
                ))}
              </motion.div>
            ) : results.length === 0 ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-16 bg-white rounded-2xl border"
              >
                <SearchIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 text-lg">没有找到相关资源</p>
                <p className="text-gray-400 text-sm mt-2">
                  尝试使用其他关键词搜索
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-3"
              >
                {results.map((link, index) => (
                  <motion.div
                    key={link.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Link
                      to={`/s/${link.slug}`}
                      className="flex items-center gap-4 p-4 bg-white rounded-xl border hover:border-indigo-200 hover:shadow-md transition-all group"
                    >
                      {/* 自定义图标或默认图标 */}
                      {getLinkIcon(link)}
                      
                      {/* 内容 */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-gray-800 group-hover:text-indigo-600 transition-colors truncate">
                          {link.name}
                        </h3>
                        <p className="text-sm text-gray-500 truncate mt-0.5">{link.description}</p>
                        <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {link.click_count?.toLocaleString()}
                          </span>
                          <span className="flex items-center gap-1 px-2 py-0.5 bg-gray-100 rounded-full text-xs">
                            {mockCategories.find(c => c.id === link.category_id)?.name || '未分类'}
                          </span>
                          {link.subcategory_id && (
                            <span className="flex items-center gap-1 px-2 py-0.5 bg-indigo-50 text-indigo-600 rounded-full text-xs">
                              {getSubCategoryName(link.subcategory_id)}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {/* 置顶标记 */}
                      {link.is_pinned && (
                        <span className="px-2 py-1 bg-amber-500 text-white text-xs rounded-full flex items-center gap-1 flex-shrink-0">
                          <Pin className="w-3 h-3" />
                          置顶
                        </span>
                      )}
                    </Link>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  )
}
