import { useState } from 'react'
import { Plus, Edit2, Trash2, GripVertical, FolderOpen, Save, X, Image, ChevronDown, ChevronRight } from 'lucide-react'
import { mockCategories, mockSubCategories } from '@/data/mock'

export default function CategoryManagementPage() {
  const [categories, setCategories] = useState(mockCategories)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const [isAdding, setIsAdding] = useState(false)
  const [newName, setNewName] = useState('')
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null)
  const [subCategories, setSubCategories] = useState(mockSubCategories)
  const [editingSubId, setEditingSubId] = useState<string | null>(null)
  const [editSubName, setEditSubName] = useState('')
  const [isAddingSub, setIsAddingSub] = useState(false)
  const [newSubName, setNewSubName] = useState('')

  const handleSave = () => {
    if (editingId) {
      setCategories(categories.map(c => c.id === editingId ? { ...c, name: editName } : c))
      setEditingId(null)
    }
  }

  const handleAdd = () => {
    if (newName.trim()) {
      setCategories([...categories, {
        id: Date.now().toString(),
        name: newName.trim(),
        icon: 'folder',
        sort_order: categories.length + 1
      }])
      setNewName('')
      setIsAdding(false)
    }
  }

  const handleDelete = (id: string) => {
    if (confirm('确定删除该分类吗？')) {
      setCategories(categories.filter(c => c.id !== id))
    }
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">分类管理</h1>
          <p className="text-gray-500 mt-1">管理资源分类</p>
        </div>
        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-medium"
        >
          <Plus className="w-5 h-5" />
          添加分类
        </button>
      </div>

      {/* Add Form */}
      {isAdding && (
        <div className="bg-white rounded-2xl border border-gray-200 p-4 mb-6">
          <div className="flex items-center gap-4">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="输入分类名称"
              className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200"
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
            />
            <button onClick={handleAdd} className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700">
              <Save className="w-5 h-5" />
            </button>
            <button onClick={() => { setIsAdding(false); setNewName(''); }} className="px-4 py-2.5 border border-gray-200 rounded-xl hover:bg-gray-50">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Categories List */}
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        <div className="grid grid-cols-12 gap-4 px-6 py-3 bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-500">
          <div className="col-span-1">排序</div>
          <div className="col-span-5">分类名称</div>
          <div className="col-span-3">资源数量</div>
          <div className="col-span-3">操作</div>
        </div>

        {categories.map((category, index) => {
          const subCats = subCategories.filter(sc => sc.category_id === category.id)
          const isExpanded = expandedCategory === category.id
          
          return (
            <div key={category.id}>
              <div className="grid grid-cols-12 gap-4 px-6 py-4 border-b border-gray-100 hover:bg-gray-50 transition-colors items-center">
                <div className="col-span-1">
                  <GripVertical className="w-5 h-5 text-gray-300 cursor-move" />
                </div>
                <div className="col-span-5">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setExpandedCategory(isExpanded ? null : category.id)}
                      className="p-0.5 hover:bg-gray-200 rounded"
                    >
                      {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </button>
                    {editingId === category.id ? (
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="px-3 py-1.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200"
                        autoFocus
                      />
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                          <FolderOpen className="w-4 h-4 text-indigo-600" />
                        </div>
                        <span className="font-medium text-gray-900">{category.name}</span>
                        {subCats.length > 0 && (
                          <span className="text-xs text-gray-400">({subCats.length} 子分类)</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                <div className="col-span-3 text-gray-500">
                  {Math.floor(Math.random() * 20)} 个资源
                </div>
                <div className="col-span-3 flex items-center gap-2">
                  <button 
                    onClick={() => { setIsAddingSub(true); setExpandedCategory(category.id); }}
                    className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                    title="添加子分类"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                  {editingId === category.id ? (
                    <>
                      <button onClick={handleSave} className="p-2 text-green-600 hover:bg-green-50 rounded-lg">
                        <Save className="w-4 h-4" />
                      </button>
                      <button onClick={() => setEditingId(null)} className="p-2 text-gray-400 hover:bg-gray-100 rounded-lg">
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <>
                      <button 
                        onClick={() => { setEditingId(category.id); setEditName(category.name); }}
                        className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(category.id)}
                        className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* 子分类列表 */}
              {isExpanded && (
                <div className="bg-gray-50 px-6 py-2">
                  {/* 添加子分类表单 */}
                  {isAddingSub && expandedCategory === category.id && (
                    <div className="flex items-center gap-2 mb-2">
                      <input
                        type="text"
                        value={newSubName}
                        onChange={(e) => setNewSubName(e.target.value)}
                        placeholder="输入子分类名称"
                        className="flex-1 px-3 py-1.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 text-sm"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            if (newSubName.trim()) {
                              setSubCategories([...subCategories, {
                                id: Date.now().toString(),
                                name: newSubName.trim(),
                                category_id: category.id,
                                sort_order: subCats.length + 1
                              }])
                              setNewSubName('')
                              setIsAddingSub(false)
                            }
                          }
                        }}
                      />
                      <button 
                        onClick={() => {
                          if (newSubName.trim()) {
                            setSubCategories([...subCategories, {
                              id: Date.now().toString(),
                              name: newSubName.trim(),
                              category_id: category.id,
                              sort_order: subCats.length + 1
                            }])
                            setNewSubName('')
                            setIsAddingSub(false)
                          }
                        }} 
                        className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg"
                      >
                        <Save className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => { setIsAddingSub(false); setNewSubName(''); }} 
                        className="p-1.5 text-gray-400 hover:bg-gray-100 rounded-lg"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  
                  {subCats.map(subCat => (
                    <div key={subCat.id} className="flex items-center gap-2 py-2 px-4">
                      {editingSubId === subCat.id ? (
                        <>
                          <input
                            type="text"
                            value={editSubName}
                            onChange={(e) => setEditSubName(e.target.value)}
                            className="flex-1 px-3 py-1.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 text-sm"
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                setSubCategories(subCategories.map(sc => 
                                  sc.id === editingSubId ? { ...sc, name: editSubName } : sc
                                ))
                                setEditingSubId(null)
                              }
                            }}
                          />
                          <button 
                            onClick={() => {
                              setSubCategories(subCategories.map(sc => 
                                sc.id === editingSubId ? { ...sc, name: editSubName } : sc
                              ))
                              setEditingSubId(null)
                            }} 
                            className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => setEditingSubId(null)} 
                            className="p-1.5 text-gray-400 hover:bg-gray-100 rounded-lg"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </>
                      ) : (
                        <>
                          <span className="flex-1 text-sm text-gray-700">{subCat.name}</span>
                          <button 
                            onClick={() => { setEditingSubId(subCat.id); setEditSubName(subCat.name); }} 
                            className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => setSubCategories(subCategories.filter(sc => sc.id !== subCat.id))} 
                            className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
