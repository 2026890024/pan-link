import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Copy,
  Check,
  Clock,
  Eye,
  Share2,
  Heart,
  ArrowLeft,
  ChevronRight,
  ExternalLink,
  Gift,
} from 'lucide-react'
import { useState } from 'react'
import { mockLinks, mockCategories, mockSubCategories } from '@/data/mock'
import { formatNumber, getDaysRemaining, copyToClipboard, checkLinkStatus } from '@/lib/utils'
import toast from 'react-hot-toast'

export default function LinkDetailPage() {
  const { slug } = useParams<{ slug: string }>()
  const [copiedField, setCopiedField] = useState<string | null>(null)
  const [isFavorite, setIsFavorite] = useState(false)

  // 从 mock 数据中查找链接
  const link = mockLinks.find((l) => l.slug === slug) || mockLinks[0]
  const category = mockCategories.find((c) => c.id === link.category_id) || mockCategories[0]
  
  // 获取子分类名称
  const subcategory = link.subcategory_id 
    ? mockSubCategories.find(sc => sc.id === link.subcategory_id)
    : null
  
  // 获取相关推荐（同分类的其他链接）
  const relatedLinks = mockLinks
    .filter((l) => l.category_id === link.category_id && l.id !== link.id)
    .slice(0, 3)

  const handleCopy = async (text: string, field: string) => {
    const success = await copyToClipboard(text)
    if (success) {
      setCopiedField(field)
      toast.success('复制成功')
      setTimeout(() => setCopiedField(null), 2000)
    } else {
      toast.error('复制失败')
    }
  }

  const handleVisit = () => {
    toast.success('即将跳转到下载页面...')
    window.open(link.url, '_blank')
  }

  const handleShare = async () => {
    const shareUrl = window.location.href
    if (navigator.share) {
      try {
        await navigator.share({
          title: link.name,
          text: `发现优质资源：${link.name}`,
          url: shareUrl,
        })
      } catch {
        // 用户取消分享
      }
    } else {
      await copyToClipboard(shareUrl)
      toast.success('分享链接已复制')
    }
  }

  const status = checkLinkStatus(link.expires_at || null)
  const daysRemaining = getDaysRemaining(link.expires_at || null)

  // 获取链接图标（优先自定义图标）
  const getLinkIcon = () => {
    if (link.icon) {
      return (
        <img
          src={link.icon}
          alt={link.name}
          className="w-20 h-20 object-contain"
        />
      )
    }
    // 显示分类图标
    return (
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center">
        <Gift className="w-10 h-10 text-indigo-600" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* 面包屑 */}
      <motion.nav
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-2 text-sm text-gray-500 mb-6"
      >
        <Link to="/" className="hover:text-indigo-600">首页</Link>
        <ChevronRight className="w-4 h-4" />
        <Link to={`/category/${category.id}`} className="hover:text-indigo-600">
          {category.name}
        </Link>
        {subcategory && (
          <>
            <ChevronRight className="w-4 h-4" />
            <span className="text-indigo-600">{subcategory.name}</span>
          </>
        )}
        <ChevronRight className="w-4 h-4" />
        <span className="text-gray-800 truncate">{link.name}</span>
      </motion.nav>

      {/* 主卡片 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white rounded-3xl shadow-xl overflow-hidden border"
      >
        {/* 顶部渐变条 */}
        <div className="h-2 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600" />

        {/* 内容区 */}
        <div className="p-8">
          {/* 图标和标题 */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring' }}
              className="w-32 h-32 mx-auto mb-6 rounded-3xl bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center shadow-lg"
            >
              {getLinkIcon()}
            </motion.div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
              {link.name}
            </h1>
            
            {/* 子分类标签 */}
            {subcategory && (
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-sm font-medium">
                  {subcategory.name}
                </span>
              </div>
            )}
            
            {/* 标签 */}
            {link.tags && link.tags.length > 0 && (
              <div className="flex items-center justify-center gap-2 flex-wrap">
                {link.tags.map((tag: any) => (
                  <span
                    key={tag.id}
                    className="px-3 py-1 rounded-full text-sm font-medium"
                    style={{ backgroundColor: `${tag.color}20`, color: tag.color }}
                  >
                    {tag.name}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* 状态提示 */}
          {status === 'expiring_soon' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center gap-3"
            >
              <Clock className="w-5 h-5 text-amber-600 flex-shrink-0" />
              <span className="text-amber-800">
                即将过期：剩余 <strong>{daysRemaining}</strong> 天
              </span>
            </motion.div>
          )}

          {/* 链接信息卡片 */}
          <div className="space-y-4 mb-8">
            {/* 链接地址 */}
            <div className="p-4 bg-gray-50 rounded-2xl">
              <label className="text-sm text-gray-500 mb-2 block">链接地址</label>
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={link.url}
                  readOnly
                  className="flex-1 bg-white px-4 py-3 rounded-xl border font-mono text-sm truncate"
                />
                <button
                  onClick={() => handleCopy(link.url, 'url')}
                  className="px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition-colors flex items-center gap-2"
                >
                  {copiedField === 'url' ? (
                    <>
                      <Check className="w-4 h-4" />
                      已复制
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      复制
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 提取码 */}
            {link.extract_code && (
              <div className="p-4 bg-gray-50 rounded-2xl">
                <label className="text-sm text-gray-500 mb-2 block">提取码</label>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={link.extract_code}
                    readOnly
                    className="flex-1 bg-white px-4 py-3 rounded-xl border font-mono text-xl text-center tracking-widest uppercase"
                  />
                  <button
                    onClick={() => handleCopy(link.extract_code!, 'code')}
                    className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl transition-colors flex items-center gap-2 font-medium"
                  >
                    {copiedField === 'code' ? (
                      <>
                        <Check className="w-4 h-4" />
                        已复制
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        一键复制
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* 有效期 */}
            <div className="p-4 bg-gray-50 rounded-2xl">
              <label className="text-sm text-gray-500 mb-2 block">有效期</label>
              <div className="flex items-center gap-3">
                <span className="flex-1 text-lg font-medium text-gray-800">
                  {daysRemaining === null ? (
                    <span className="text-green-600 flex items-center gap-2">
                      <Check className="w-5 h-5" />
                      永久有效
                    </span>
                  ) : (
                    `剩余 ${daysRemaining} 天`
                  )}
                </span>
                <span className="text-sm text-gray-500">
                  创建于 {new Date(link.created_at).toLocaleDateString('zh-CN')}
                </span>
              </div>
            </div>
          </div>

          {/* 统计数据 */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="p-4 rounded-2xl text-center border border-gray-100">
              <div className="flex items-center justify-center gap-2 text-indigo-600 mb-1">
                <Eye className="w-5 h-5" />
                <span className="text-2xl font-bold">{formatNumber(link.click_count)}</span>
              </div>
              <span className="text-sm text-gray-600">点击访问</span>
            </div>
            <div className="p-4 rounded-2xl text-center border border-gray-100">
              <div className="flex items-center justify-center gap-2 text-green-600 mb-1">
                <Gift className="w-5 h-5" />
                <span className="text-2xl font-bold">{formatNumber(link.registration_count || 0)}</span>
              </div>
              <span className="text-sm text-gray-600">注册转化</span>
            </div>
          </div>

          {/* 主按钮 */}
          <div className="space-y-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleVisit}
              className="w-full py-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white rounded-2xl font-semibold text-lg flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-shadow"
            >
              <ExternalLink className="w-6 h-6" />
              立即访问
            </motion.button>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setIsFavorite(!isFavorite)}
                className={`py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors ${
                  isFavorite
                    ? 'bg-red-50 text-red-600 border border-red-200'
                    : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
                {isFavorite ? '已收藏' : '收藏'}
              </button>
              <button
                onClick={handleShare}
                className="py-3 bg-gray-50 text-gray-600 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-gray-100 transition-colors"
              >
                <Share2 className="w-5 h-5" />
                分享
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* 相关推荐 */}
      {relatedLinks.length > 0 && (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-12"
        >
          <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <Gift className="w-5 h-5 text-purple-600" />
            相关推荐
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            {relatedLinks.map((relatedLink) => (
              <Link
                key={relatedLink.id}
                to={`/s/${relatedLink.slug}`}
                className="block p-4 bg-white rounded-xl border hover:border-indigo-200 hover:shadow-md transition-all group"
              >
                <div className="flex items-center gap-3 mb-3">
                  {/* 相关推荐链接的图标 */}
                  {relatedLink.icon ? (
                    <img
                      src={relatedLink.icon}
                      alt={relatedLink.name}
                      className="w-10 h-10 object-contain rounded-lg"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                      <Gift className="w-5 h-5 text-gray-400" />
                    </div>
                  )}
                  <h3 className="font-medium text-gray-800 group-hover:text-indigo-600 transition-colors truncate flex-1">
                    {relatedLink.name}
                  </h3>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    {formatNumber(relatedLink.click_count)}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </motion.section>
      )}

      {/* 返回按钮 */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-12 text-center"
      >
        <Link
          to={`/category/${category.id}`}
          className="inline-flex items-center gap-2 text-indigo-600 hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          返回{category.name}
        </Link>
      </motion.div>
    </div>
  )
}
